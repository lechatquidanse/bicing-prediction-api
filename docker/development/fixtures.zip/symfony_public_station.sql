create table station
(
  station_id          uuid         not null
    constraint station_pkey
      primary key,
  created_at          timestamp(0) not null,
  updated_at          timestamp(0) default NULL :: timestamp without time zone,
  station_detail_name varchar(255) not null,
  station_detail_type varchar(255) not null,
  location_geometry varchar(255) null
    constraint station_station_detail_type_check
      check ((station_detail_type) :: text = ANY
    ((ARRAY ['BIKE' :: character varying, 'ELECTRIC_BIKE' :: character varying]) :: text [])
),
  station_external_data_external_station_id varchar
(
  255
) not null,
  station_external_data_near_by_external_station_ids text not null,
  location_address varchar
(
  255
) not null,
  location_address_number varchar
(
  10
) default NULL :: character varying,
  location_district_code smallint not null,
  location_zip_code varchar
(
  5
) not null,
  location_latitude double precision not null,
  location_longitude double precision not null
  );

comment
on
column
station
.
station_id
is
'(DC2Type:uuid)';

comment
on
column
station
.
created_at
is
'(DC2Type:datetime_immutable)';

comment
on
column
station
.
updated_at
is
'(DC2Type:datetime_immutable)';

comment
on
column
station
.
station_detail_type
is
'(DC2Type:enum_station_detail_type_type)';

comment
on
column
station
.
station_external_data_near_by_external_station_ids
is
'(DC2Type:simple_array)';

create
unique
index
unique_station_external_external_station_id
on
station
(
station_external_data_external_station_id
);

CREATE
UNIQUE
INDEX
unique_station_external_external_station_id
ON
station
(
station_external_data_external_station_id
);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('cc90eb4e-4988-4443-aedf-6464f79eeb12', '2018-09-03 17:20:21', null, '01 - C/ GRAN VIA CORTS CATALANES 760', 'BIKE',
 '1', '24,369,387,426', 'Gran Via Corts Catalanes', '760', 2, '08013', 41.397952, 2.180042, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('630863d3-510c-4dba-8a39-bb1404ebbb78', '2018-09-03 17:20:21', null, '02 - C/ ROGER DE FLOR, 126', 'BIKE', '2',
 '360,368,387,414', 'Roger de Flor/ Gran Vía', '126', 2, '08010', 41.39553, 2.17706, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a0dcc05c-ad7d-479f-9a42-87d061505c84', '2018-09-03 17:20:22', null, '03 - C/ NÀPOLS, 82', 'BIKE', '3', '4,6,119,419',
 'Nàpols', '82', 2, '08013', 41.394072, 2.183441, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('fce3ded6-ad23-4889-99db-6b6805eef760', '2018-09-03 17:20:22', null, '04 - C/ RIBES 13', 'BIKE', '4', '3,5,359,419',
 'Ribes', '13', 2, '08013', 41.39347, 2.18149, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('bcc7c3d4-0a75-4cb5-96c6-5260ae959bb1', '2018-09-03 17:20:22', null, '05 - PG. LLUIS COMPANYS 11 (ARC TRIOMF)', 'BIKE',
 '5', '6,7,359,418', 'Pg Lluís Companys', '11', 1, '08003', 41.391075, 2.180223, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4cf351d8-ebcc-44fc-9dec-fa23bb6103b6', '2018-09-03 17:20:22', null, '06 - PG. LLUIS COMPANYS 18  (ARC TRIOMF)',
 'BIKE', '6', '5,8,359,419', 'Pg Lluís Companys', '18', 1, '08018', 41.391349, 2.18061, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2221f2df-84e3-49c1-8e67-55c096161deb', '2018-09-03 17:20:22', null, '07 - PG. PUJADES  1 (JUTJATS)', 'BIKE', '7',
 '8,118,389', 'Pg Lluís Companys', '1', 1, '08003', 41.388856, 2.183251, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ae51a8d6-5bef-4571-870b-e36c35a09b89', '2018-09-03 17:20:22', null, '08 - PG. PUJADES 2', 'BIKE', '8', '6,118,389',
 'Pg Lluís Companys', '2', 1, '08018', 41.389088, 2.183568, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('fa495fe2-7017-4c9a-995e-84ff7c4a5711', '2018-09-03 17:20:22', null, '09 - AV. MARQUÉS DE L''ARGENTERA 13', 'BIKE',
 '9', '14,40,115,389,390', 'Marquès de l''Argentera', '13', 1, '08003', 41.384532, 2.184921, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('923702c1-a4d7-4754-ada3-2448d3044e5b', '2018-09-03 17:20:22', null, '11 - PG. MARITIM, 19', 'BIKE', '11',
 '116,124,125,396', 'Passeig Marítim', '19', 1, '08003', 41.381689, 2.193914, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('19332d1f-cddf-4e8a-a4cd-1e73a03e16a6', '2018-09-03 17:20:22', null, '12 - PG. MARITIM 23 (HOSPITAL DEL MAR)', 'BIKE',
 '12', '11,13,116,396', 'Pg Marítim Barceloneta', '23', 1, '08003', 41.384538, 2.195679, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e17a6ac2-a99b-4305-abd6-40b5859789d6', '2018-09-03 17:20:22', null, '13 - AV. LITORAL 22 (H. ARS)', 'BIKE', '13',
 '11,12,46,69', 'Avinguda Litoral', '16', 1, '08005', 41.386861, 2.195761, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('f78828de-a4ac-4e15-a5ef-511a8674b198', '2018-09-03 17:20:22', null, '14 - AV. MARQUÉS DE  L''ARGENTERA 15', 'BIKE',
 '14', '9,40,115,389,390', 'Avinguda del Marques Argentera', '15', 1, '08003', 41.384675, 2.185039, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2a7c5e3f-8e60-4b07-9190-512b4f64c9e5', '2018-09-03 17:20:22', null, '15 - C/ GIRONA, 68', 'BIKE', '15',
 '23,25,362,413', 'Girona', '68', 2, '08009', 41.394812, 2.171189, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d074219a-41e9-41a0-b671-3cc68478eeb8', '2018-09-03 17:20:22', null, '16 - AV. MERIDIANA 47', 'BIKE', '16',
 '17,44,48,372', 'Av. Meridiana', '47', 2, '08018', 41.39827, 2.186708, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a74b5ce3-6a68-4609-9526-f5a2a4723ad1', '2018-09-03 17:20:22', null, '17 - AV. MERIDIANA, 47 (ANNEXA A LA 16)', 'BIKE',
 '17', '16,48,211,372', 'Av. Meridiana', '47', 2, '08013', 41.398237, 2.186711, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('eb3a9740-0b0b-4ee6-8b26-e30320904ffd', '2018-09-03 17:20:22', null, '18 - C/ ROSSELLÓ 453', 'BIKE', '18',
 '19,28,120,370', 'Rosselló', '453', 2, '08025', 41.406086, 2.174167, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('bd1f049a-40ff-4245-b23f-3d6fd05b0728', '2018-09-03 17:20:22', null, '19 - C/ ROSSELLÓ 354', 'BIKE', '19',
 '18,22,29,370', 'Rosselló', '354', 2, '08025', 41.403282, 2.170726, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0d4b278e-2e5a-4cc6-b0cc-2f2c46923163', '2018-09-03 17:20:22', null, '20 - C/ CARTAGENA, 308', 'BIKE', '20',
 '21,28,164,177,278', 'Cartagena', '308', 2, '08025', 41.410166, 2.175759, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('243eba4a-a9fa-4516-abe8-6c171d5175f9', '2018-09-03 17:20:22', null, '21 - C/ SANT ANTONI MARIA CLARET 214', 'BIKE',
 '21', '20,28,164,278', 'Sant Antoni Maria Claret', '214', 2, '08025', 41.410897, 2.17402, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('18d2104c-0b92-4feb-8d60-ce2c3c5a7197', '2018-09-03 17:20:22', null, '22 - C/ SARDENYA, 292', 'BIKE', '22',
 '29,120,369,370', 'Sardenya', '292', 2, '08025', 41.401684, 2.17568, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('043270ef-157e-45e0-9b90-2e7ba7d55804', '2018-09-03 17:20:22', null, '23 - C/ BRUC 45', 'BIKE', '23', '15,360,363,413',
 'Bruc', '45', 2, '08010', 41.392526, 2.171812, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('759dd556-e8ac-46eb-86bf-6c96b322c54e', '2018-09-03 17:20:22', null, '24 - C/ MARINA 199', 'BIKE', '24',
 '1,30,369,426', 'Marina', '199', 2, '08013', 41.400659, 2.179111, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('374c5b80-cb51-46d8-8f7d-48bce9044f23', '2018-09-03 17:20:22', null, '25 - C/ BRUC 102', 'BIKE', '25',
 '15,123,362,413', 'Bruc', '102', 2, '08009', 41.395179, 2.168294, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3a4211a9-c071-405c-a61f-c459ebb9e8dc', '2018-09-03 17:20:22', null, '26 - C/ DOS DE MAIG 230-232', 'BIKE', '26',
 '120,121,177,371', 'Dos Maig', '230', 8, '08013', 41.407035, 2.181981, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('15cb8a93-9591-426b-803e-455b2540546f', '2018-09-03 17:20:22', null, '27 - C/ PROVENÇA, 322', 'BIKE', '27',
 '123,189,224,374', 'Provença', '322', 2, '08037', 41.396881, 2.164415, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('241f1994-d970-4b87-9183-afd2eb92b654', '2018-09-03 17:20:22', null, '28 - C/ SARDENYA, 362', 'BIKE', '28',
 '18,20,122,277', 'Sardenya', '362', 2, '08025', 41.405422, 2.17064, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('52798a4a-5d4f-4252-905c-18206a882f3f', '2018-09-03 17:20:22', null, '29 - C/ PROVENÇA 388-390', 'BIKE', '29',
 '19,224,360,370', 'Provença', '388', 2, '08025', 41.401101, 2.170082, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('70346ace-91d2-43c8-b7d9-19b5c62b7cd4', '2018-09-03 17:20:22', null, '30 - AV. DIAGONAL, 231 / PADILLA', 'BIKE', '30',
 '24,218,369,371', 'Diagonal', '231', 2, '08013', 41.402046, 2.182286, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('06f26d07-49d9-4ea8-a811-7269c0dbda98', '2018-09-03 17:20:22', null, '31 - PL. DEL MAR', 'BIKE', '31', '33,41,124',
 'Plaça del Mar', '72', 1, '08003', 41.37481, 2.18895, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('01572ed6-943c-4199-a96b-1b648039e1aa', '2018-09-03 17:20:22', null, '32 - LA BARCELONETA (CN BARCELONETA)', 'BIKE',
 '32', '31,33,124,400', 'Plaça del Mar', '1', 1, '08003', 41.373698, 2.188927, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('9a2cb333-b50a-4eab-9824-50cd57ca43dd', '2018-09-03 17:20:22', null, '33 - C/PONTEVEDRA / JUDICI', 'BIKE', '33',
 '31,41,124,424', 'Pontevedra', '58B', 1, '08003', 41.376862, 2.190773, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('f2a8f20b-1bf7-411e-a3ec-fcb95868bafb', '2018-09-03 17:20:22', null, '34 - C/ SANT PERE MÉS ALT, 4', 'BIKE', '34',
 '36,105,359,380', 'Sant Pere Més Alt', '4', 1, '08003', 41.387074, 2.175247, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b2471a20-c2d4-4426-b931-4ca76282d4c0', '2018-09-03 17:20:22', null, '35 - C/ SANT RAMON DE PENYAFORT', 'BIKE', '35',
 '157,158,159,160', 'Sant Ramon de Penyafort', '1', 8, '08019', 41.413592, 2.221153, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('44c3d445-0a26-465b-8f96-07e683c58e42', '2018-09-03 17:20:22', null, '36 - AV. DE LA CATEDRAL 6', 'BIKE', '36',
 '34,35,53,358,380', 'Catedral', '6', 1, '08002', 41.385151, 2.176804, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('72afee77-9d59-4607-a47f-f852d820afc5', '2018-09-03 17:20:22', null, '37 - PL. ANTONIO LÓPEZ (CORREUS, VIA LAIETANA)',
 'BIKE', '37', '38,115,126,401', 'Pl. Antonio López', null, 1, '08003', 41.381226, 2.181888, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('840b7179-6a6a-4564-840c-3479316cda81', '2018-09-03 17:20:22', null, '38 - PL. PAU VILA', 'BIKE', '38', '40,124,126',
 'Pl. Pau Vila', null, 1, '08003', 41.381129, 2.186397, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('25a1c2f4-9cc4-417b-97a6-2bec7709a24a', '2018-09-03 17:20:22', null, '39 - PL. PAU VILA', 'BIKE', '39',
 '38,40,124,126', 'Pl. Pau Vila', null, 1, '08003', 41.381046, 2.186576, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('291923de-b6fa-49a2-9845-759608e6e68a', '2018-09-03 17:20:22', null, '40 - C/ DOCTOR AIGUADER, 2', 'BIKE', '40',
 '37,38,116,402', 'Doctor Aiguader', '2', 1, '08003', 41.382335, 2.187093, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('45b6962c-a29a-40c2-a90b-f781a6812f14', '2018-09-03 17:20:22', null, '41 - PL. POETA BOSCÀ/ATLÀNTIDA', 'BIKE', '41',
 '31,124,424', 'Pl. Poeta Boscà/Atlàntida', null, 1, '08003', 41.379326, 2.189906, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('845abff6-f7bd-4f7e-bfbf-5df9ec7b25ed', '2018-09-03 17:20:22', null, '42 - C/ CIUTAT DE GRANADA 168 / AV. DIAGONAL',
 'BIKE', '42', '43,44,133,286', 'Ciutat de Granada', '168', 8, '08018', 41.404511, 2.189881, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('bccddb2b-71af-4942-84e4-bb9a3f9a53b8', '2018-09-03 17:20:22', null, '43 - AV. MERIDIANA, 80', 'BIKE', '43',
 '30,42,44,218', 'Av Meridiana', '80', 8, '08026', 41.40541, 2.18712, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('04d94f01-5e10-47f5-9ac8-a4dd2de94602', '2018-09-03 17:20:22', null, '44 - AV. MERIDIANA, 66 ( COSTAT METRO GLORIES)',
 'BIKE', '44', '30,42,43,286', 'Av Meridiana', '66', 8, '08026', 41.402165, 2.187136, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8cd849af-6b88-4e12-85ac-8a7f269a8667', '2018-09-03 17:20:22', null, '45 - C/ SARDENYA, 66', 'BIKE', '45',
 '47,118,392,409', 'Marina', '66', 8, '08005', 41.391401, 2.189399, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e0d5cf67-eae9-4223-bad2-1eca65cbda5c', '2018-09-03 17:20:22', null, '46 - C/ RAMON TRIAS FARGAS 19', 'BIKE', '46',
 '47,69,392,407', 'Ramon trias Fargas', '19', 8, '08005', 41.388359, 2.193004, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('91c7dcfd-b9f7-4212-a116-7d5914e66ba0', '2018-09-03 17:20:22', null, '47 - C/ RAMON TRIAS FARGAS 21', 'BIKE', '47',
 '13,46,392,407', 'Ramon Trias Fargas', null, 8, '08005', 41.389076, 2.192104, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('7a470208-5767-43d2-ac62-a4de320e06d4', '2018-09-03 17:20:22', null, '48 - AV. MERIDIANA 40', 'BIKE', '48',
 '16,118,149,211', 'Meridiana', '40', 8, '08018', 41.395261, 2.18708, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('87e3926c-a123-41b1-a468-7de1bfdf8fb7', '2018-09-03 17:20:22', null, '49 - C/ ROSA SENSAT  20', 'BIKE', '49',
 '46,117,163,396', 'Rosa Sensat en front', '20', 8, '08005', 41.39106, 2.196457, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('774db08a-72ea-4a66-8a0f-d3eb7c66d306', '2018-09-03 17:20:22', null, '50 - AV. PARAL.LEL, 54', 'BIKE', '50',
 '114,187,232,233', 'Av. Paral.lel', '54', 1, '08001', 41.375, 2.17035, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1092c0c6-7ab3-4053-9747-82855770e8e5', '2018-09-03 17:20:22', null, '51 - PL. VICENÇ MARTORELL', 'BIKE', '51',
 '55,58,59,63', 'Pl. Vicenç Martorell', null, 1, '08001', 41.384054, 2.169019, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('abaf14e4-d272-43c1-a252-531264715cfc', '2018-09-03 17:20:22', null, '53 - PL. CARLES PI I SUNYER', 'BIKE', '53',
 '34,36,380,395', 'Pl. Carles Pi i Sunyer', null, 1, '08002', 41.385227, 2.173878, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a5f6fe22-c7d1-4a32-b42a-d8cc37d28f17', '2018-09-03 17:20:22', null, '54 - C/ SANT OLEGUER 2', 'BIKE', '54',
 '114,187,388,415', 'Sant Oleguer', '2', 1, '08001', 41.377635, 2.170586, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('cb4ac2b3-ffbd-4bf0-84f8-a375d2364e7d', '2018-09-03 17:20:22', null, '55 - LA RAMBLA, 80', 'BIKE', '55',
 '54,378,379,395', 'La Rambla', '80', 1, '08002', 41.381154, 2.173497, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6b863428-77b4-4d6e-b3fa-876247d2b253', '2018-09-03 17:20:22', null, '56 - PORTAL DE SANTA MADRONA, 2-4', 'BIKE', '56',
 '54,57,378,425', 'Portal de Santa Madrona', '2', 1, '08001', 41.377011, 2.175834, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d652a95b-150f-4a26-8f47-89b59495a4e9', '2018-09-03 17:20:22', null, '57 - RAMBLA, 2', 'BIKE', '57', '56,114,361,378',
 'La Rambla', '2', 1, '08002', 41.376758, 2.177093, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('7bdfc5d5-ebb7-4b83-af30-4f37f061892c', '2018-09-03 17:20:22', null, '58 - PLAÇA DELS ÀNGELS ( MACBA )', 'BIKE', '58',
 '51,59,381,388', 'Plaça dels Àngels', '1', 1, '08001', 41.382822, 2.167154, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('da50f9c2-78f9-49b5-8edf-4928d35cca41', '2018-09-03 17:20:22', null, '59 - PLAÇA DELS ÀNGELS ( MACBA )', 'BIKE', '59',
 '51,58,381,388', 'Plaça dels Àngels', '2', 1, '08001', 41.382781, 2.167203, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ddc69a5b-4747-4cf1-bcf0-dc94eda9b611', '2018-09-03 17:20:22', null, '60 - RAMBLA CATALUNYA, 47', 'BIKE', '60',
 '61,66,80,364', 'Rambla Catalunya', '47', 2, '08007', 41.390349, 2.16424, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('fbd4e878-abbe-4e1f-a229-927c106909e9', '2018-09-03 17:20:22', null, '61 - RAMBLA CATALUNYA, 42', 'BIKE', '61',
 '60,80,287,364', 'Rambla Catalunya', '42', 2, '08007', 41.390143, 2.164946, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3733db8b-a48d-49a3-9d86-32d698eaec77', '2018-09-03 17:20:22', null, '62 - PL. CATALUNYA, 5', 'BIKE', '62',
 '63,64,65,395', 'Pl. Catalunya', '5', 2, '08002', 41.387142, 2.168858, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('5c9d61c4-5e27-41a2-9595-c1a6c4e00ac2', '2018-09-03 17:20:22', null, '63 - PL. CATALUNYA, 7', 'BIKE', '63',
 '62,64,65,395', 'Pl. Catalunya', '7', 2, '08002', 41.386439, 2.169417, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2f009f16-4024-4ea4-bcda-c81000dd9407', '2018-09-03 17:20:22', null, '64 - PL. CATALUNYA 10-11 (RAMBLA)', 'BIKE', '64',
 '62,63,65,395', 'Pl. Catalunya', null, 2, '08002', 41.387469, 2.169048, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('21a0ebdd-7fe8-40ba-8441-454880c87e8f', '2018-09-03 17:20:22', null, '65 - PL. CATALUNYA 10-11 (PG. DE GRACIA)',
 'BIKE', '65', '62,63,64,395', 'Pl. Catalunya', null, 2, '08002', 41.387678, 2.169587, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('9253a6f3-7a17-4673-a3b5-b0777d380aec', '2018-09-03 17:20:22', null, '66 - GRAN VIA DE LES CORTS CATALANES, 609',
 'BIKE', '66', '61,64,79,287', 'Gran Via', '609', 2, '08007', 41.389097, 2.167933, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('5a2d579f-554c-4468-8edb-55850d09af4c', '2018-09-03 17:20:22', null, '67 - C/ ROCAFORT, 214 / ROSSELLÓ', 'BIKE', '67',
 '75,87,89,365', 'Rocafort', '214', 2, '08029', 41.385012, 2.145843, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b88851b9-4695-498f-ab98-f7e4f0860357', '2018-09-03 17:20:22', null, '68 - RAMBLA CATALUNYA, 133 /  CÒRSEGA', 'BIKE',
 '68', '72,73,92,374', 'Rambla Catalunya', '133', 2, '08007', 41.395364, 2.157356, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ada05be1-d908-45fb-b373-4f206e8727fe', '2018-09-03 17:20:22', null, '69 - AV. LITORAL 22 (HOTEL ARS ANNEXA A LA 13)',
 'BIKE', '69', '12,13,125,397', 'Avda. Litoral', null, 1, '08005', 41.386814, 2.195689, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d89c130e-bdf8-49d9-b3c6-a913ee42ee9b', '2018-09-03 17:20:22', null, '70 - C/ COMTE URGELL 23', 'BIKE', '70',
 '71,91,113,261', 'Comte Urgell', '23', 2, '08011', 41.380347, 2.160695, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a7ac34b7-9375-45f8-b27e-905a9ac52c17', '2018-09-03 17:20:22', null, '71 - C/ FLORIDABLANCA 145', 'BIKE', '71',
 '70,78,113,148', 'Floridablanca', '145', 2, '08011', 41.381931, 2.162969, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e59ec933-0c15-4539-a81a-dbe43fa0bd61', '2018-09-03 17:20:22', null, '72 - C/ PROVENÇA, 215', 'BIKE', '72',
 '68,73,92,374', 'Provença', '215', 2, '08008', 41.392716, 2.158811, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('47916cd9-60e0-4060-829d-ec40d591b350', '2018-09-03 17:20:22', null, '73 - C/ ENRIC GRANADOS 93', 'BIKE', '73',
 '68,72,76,92', 'Enric Granados', '93', 2, '08008', 41.392278, 2.156183, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b02f4c8f-45b3-4594-bc26-cd883865de33', '2018-09-03 17:20:22', null, '74 - AV. JOSEP TARRADELLAS 133', 'BIKE', '74',
 '101,102,109,366', 'Josep Tarradellas', '133', 2, '08029', 41.390062, 2.143272, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c616c5e4-738b-4012-885a-063f8b25b85b', '2018-09-03 17:20:22', null, '75 - AV. JOSEP TARRADELLAS 58', 'BIKE', '75',
 '99,197,365', 'Josep Tarradellas', '58', 2, '08029', 41.385081, 2.142868, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1caaa166-9bba-4310-9061-d6c903fbf959', '2018-09-03 17:20:22', null, '76 - CÒRSEGA, 216', 'BIKE', '76', '72,73,88,90',
 'Còrsega', '216', 2, '08036', 41.391751, 2.153123, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('86c766bc-931f-4ff3-8454-8f68c822e797', '2018-09-03 17:20:23', null, '78 - PL. UNIVERSITAT / ARIBAU', 'BIKE', '78',
 '71,79,209,406', 'Pl. Universitat', null, 2, '08007', 41.385598, 2.16338, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('fb04288d-1720-4e6e-9455-ee1166418f53', '2018-09-03 17:20:23', null, '79 - PL. UNIVERSITAT', 'BIKE', '79',
 '78,209,287,406', 'Pl. Universitat', null, 2, '08007', 41.38547, 2.16333, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('7d6a1d87-f471-4d3d-a0f5-9985d55fa84d', '2018-09-03 17:20:23', null, '80 - C/ ENRIC GRANADOS 35', 'BIKE', '80',
 '60,209,385,394', 'Enric Granados', '35', 2, '08007', 41.389687, 2.159999, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('5afb91ac-fd0d-4bd1-b895-befb19c0ee36', '2018-09-03 17:20:23', null, '81 - C/ VILAMARÍ, 61', 'BIKE', '81',
 '82,95,97,384', 'Vilamarí davant', '61', 2, '08015', 41.378915, 2.149174, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0f290394-11cf-40e2-a46d-9b624e953b5c', '2018-09-03 17:20:23', null, '82 - C/ ROCAFORT 72-74', 'BIKE', '82',
 '81,111,112', 'Rocafort', '72', 2, '08015', 41.379016, 2.153799, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('735af92e-661e-4055-b94d-8fc6ce6cc5e3', '2018-09-03 17:20:23', null, '83 - C/ COMTE BORRELL 177', 'BIKE', '83',
 '87,89,110,111', 'Comte Borrell', '177', 2, '08015', 41.384075, 2.153654, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d520c99a-2031-4628-bb3f-c59527e98f43', '2018-09-03 17:20:23', null, '84 - C/ DEL COMTE D''URGELL 75 B', 'BIKE', '84',
 '78,91,110,209', 'Comte d''Urgell', '75 B', 2, '08011', 41.383047, 2.157033, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2f885f82-534a-4a63-8c7e-2ceddf1e4bb6', '2018-09-03 17:20:23', null, '85 - AV. PARAL·LEL 146 BIS', 'BIKE', '85',
 '112,129,235,236', 'Paral·lel', '146', 1, '08015', 41.375076, 2.159046, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('bedbd8d6-53a5-4cbe-896c-2d960be9047e', '2018-09-03 17:20:23', null, '86 - C/ VILADOMAT, 2', 'BIKE', '86',
 '85,187,235,373', 'Viladomat', '2', 2, '08015', 41.37544, 2.163, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('eaff68bd-c87b-4a21-a14c-c95ac7a77ea4', '2018-09-03 17:20:23', null, '87 - C/ MALLORCA 41-43', 'BIKE', '87',
 '111,191,384', 'Mallorca', '41', 2, '08029', 41.383156, 2.148506, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d94c2940-e0ce-4c41-bfee-e34414fcc0d9', '2018-09-03 17:20:23', null, '88 - C/LONDRES 101-103', 'BIKE', '88',
 '76,109,220,350', 'Londres', '101', 2, '08036', 41.393547, 2.150764, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2f9d0fb5-ed27-484b-83ed-27f48c4b95c6', '2018-09-03 17:20:23', null, '89 - C/ ROSSELLÓ, 101', 'BIKE', '89',
 '76,90,110,365', 'Rosselló', '101', 2, '08036', 41.387953, 2.150169, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e2337ee5-3331-4c26-bab8-6db1a9869abe', '2018-09-03 17:20:23', null, '90 - C/ ROSSELLÓ 108-110', 'BIKE', '90',
 '76,89,365,385', 'Rosselló', '108', 2, '08036', 41.38834, 2.150825, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4c88566f-ee37-4fff-a159-ccca8ba837db', '2018-09-03 17:20:23', null, '91 - C/COMTE DE BORRELL 119', 'BIKE', '91',
 '70,112,113,261', 'Comte Borrell', '119', 2, '08015', 41.380452, 2.158403, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('986e07a6-8074-4161-a5c9-74bc5215eb45', '2018-09-03 17:20:23', null, '92 - C/PROVENÇA 241', 'BIKE', '92',
 '72,73,364,374', 'Provença', '241', 2, '08008', 41.39386, 2.160237, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('9260f0d8-54e4-48d9-81fe-4a679a941b8d', '2018-09-03 17:20:23', null, '93 - GRAN VIA DE LES CORTS CATALANES, 375-385',
 'BIKE', '93', '94,95,96,420', 'Gran Via', '375', 2, '08015', 41.375454, 2.149786, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d078efa3-fd1c-4dd0-ae36-d24ac9f879b2', '2018-09-03 17:20:23', null, '94 - GRAN VIA DE LES CORTS CATALANES, 375-385',
 'BIKE', '94', '93,95,96,420', 'Gran Via', '375', 2, '08015', 41.375619, 2.149889, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c7c571c4-8fcb-45ce-9c88-7aa35d7145e8', '2018-09-03 17:20:23', null, '95 - C/ TARRAGONA 103-115', 'BIKE', '95',
 '93,96,97,186', 'Tarragona', '103', 3, '08015', 41.376428, 2.147734, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0cdcf7ff-8216-4edf-be40-90adcad7f8c7', '2018-09-03 17:20:23', null, '96 - GRAN VIA DE LES CORTS CATALANES, 361',
 'BIKE', '96', '93,95,186,420', 'Gran Via', '361', 3, '08004', 41.374152, 2.148154, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2bcfe773-0759-4cc8-a2f5-67ddb4aa32fa', '2018-09-03 17:20:23', null, '97 - C/ TARRAGONA 141', 'BIKE', '97',
 '81,95,100,186', 'Tarragona', '141', 3, '08014', 41.378124, 2.145389, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('145d4226-afdf-4eb7-9992-77a67defc1ff', '2018-09-03 17:20:23', null, '98 - C/ VIRIAT, 43', 'BIKE', '98',
 '75,99,100,421', 'Viriat', '45', 3, '08014', 41.380499, 2.141153, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('df520823-914d-4b9d-a276-74cf17479c76', '2018-09-03 17:20:23', null, '99 - C/ VIRIAT, 53', 'BIKE', '99',
 '98,100,195,421', 'Viriat', '53', 2, '08014', 41.380632, 2.141548, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('72231023-e3ab-4703-8b5d-d8455fb855eb', '2018-09-03 17:20:23', null, '100 - C/ TARRAGONA, 159-173', 'BIKE', '100',
 '97,98,99,384', 'Tarragona', '159', 3, '08014', 41.379135, 2.14409, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3ca5df05-77e5-46f4-9353-a2cce19bef25', '2018-09-03 17:20:23', null, '101 - AV. DIAGONAL, 602', 'BIKE', '101',
 '74,102,319,366', 'Av. Diagonal', '602', 6, '08021', 41.39243, 2.14321, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('95456e67-4094-45ef-98ff-403c08ef31b6', '2018-09-03 17:20:23', null, '102 - AV. DIAGONAL, 612', 'BIKE', '102',
 '74,102,319,366', 'Av. Diagonal', '612', 6, '08021', 41.39218, 2.14213, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('fcda82b7-70c8-4feb-8d33-7732df7c09ee', '2018-09-03 17:20:23', null, '103 - C/ ARAGÓ 629', 'BIKE', '103',
 '26,104,127,132', 'Aragó', '629', 8, '08026', 41.409856, 2.188217, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e11d73b3-fa1a-4ca5-84f8-b1fe17c060dc', '2018-09-03 17:20:23', null, '104 - C/ VALÈNCIA, 621', 'BIKE', '104',
 '26,103,127,177', 'C/València', '621', 8, '08026', 41.410821, 2.187365, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8ecd6b18-e13b-41d2-be00-da6525702d12', '2018-09-03 17:20:23', null, '105 - PL. URQUINAONA, 9-10', 'BIKE', '105',
 '65,359,363,412', 'PL. Urquinaona', '9', 2, '08010', 41.389069, 2.173424, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('acfe0b46-f00d-48ee-9400-b11de07de3b5', '2018-09-03 17:20:23', null, '106 - PL. JOANIC- C/ BRUNIQUER, 59', 'BIKE',
 '106', '108,122,226,231', 'Pl. Joanic', 's/n', 5, '08024', 41.405587, 2.162317, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a2bfef0e-d35c-4c9d-b3fa-607c729fec7e', '2018-09-03 17:20:23', null, '107 - TRAV. DE GRÀCIA 92 / VIA AUGUSTA', 'BIKE',
 '107', '68,219,220,223', 'Travessera de Gracia', '92', 6, '08006', 41.398298, 2.153128, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ae84aeed-ab65-4d68-9706-12aa3c3fa157', '2018-09-03 17:20:23', null, '108 - C/ INDÚSTRIA 10', 'BIKE', '108',
 '29,122,224,226', 'Indústria', '10', 5, '08037', 41.402314, 2.164961, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6bc9e63e-ed3b-401f-9b02-9d663a55bb90', '2018-09-03 17:20:23', null, '109 - C/ LONDRES, 53', 'BIKE', '109',
 '89,101,350,365', 'C/ Londres', '53', 2, '08036', 41.390981, 2.14737, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e45468c4-3ccb-4497-a674-79238d9f0e5c', '2018-09-03 17:20:23', null, '110 - AV. ROMA, 136', 'BIKE', '110',
 '83,84,209,385', 'Avda. Roma', '136', 2, '08011', 41.385377, 2.154878, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8af7ddf9-d2ba-4cb1-bcc3-6a73876ded30', '2018-09-03 17:20:23', null, '111 - C/CALÀBRIA, 137', 'BIKE', '111',
 '81,82,83,262', 'Calabria', '137', 2, '08015', 41.381231, 2.152755, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c11cf698-c0ac-4f66-a991-03fe1d3f029a', '2018-09-03 17:20:23', null, '112 - C/FLORIDABLANCA, 49', 'BIKE', '112',
 '82,91,94,113', 'Floridablanca', '49', 2, '08015', 41.377644, 2.15725, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b9305fdd-ff53-49c1-932c-af5b8cbe0fb3', '2018-09-03 17:20:23', null, '113 - RONDA DE SANT PAU, 51', 'BIKE', '113',
 '70,112,129,427', 'Sant Pau', '51', 1, '08001', 41.37742, 2.1647, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a327b78f-fe5c-444e-ab38-4142c350f74c', '2018-09-03 17:20:23', null, '114 - PL. JEAN GENET, 1', 'BIKE', '114',
 '50,54,56,425', 'Pl. Jean Genet', '1', 1, '08001', 41.376801, 2.173039, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b3c127e0-d040-4758-8853-eeffeb5e9fd8', '2018-09-03 17:20:23', null, '115 - AV. MARQUÉS DE L''ARGENTERA, 3', 'BIKE',
 '115', '14,37,401', 'Marqués d''Argentera', '3', 1, '08003', 41.38377, 2.18424, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('aebbe389-628c-48c1-b383-e0b9facbb1ea', '2018-09-03 17:20:23', null,
 '116 - C/DEL DR. AIGUADER, 72 /PG. SALVAT PAPASSEIT', 'BIKE', '116', '11,13,38', 'Salvat Papasseit', '72', 1, '08003',
 41.383718, 2.191414, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('f0a4d755-76bc-4c3b-b707-4c990dddb092', '2018-09-03 17:20:23', null, '117 - C/ROSA SENSAT, 12', 'BIKE', '117',
 '46,49,163,396', 'Rosa Sensat', '12', 8, '08005', 41.390666, 2.197024, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('60dbd9c6-d1a8-4a6e-9d94-49d89a11201a', '2018-09-03 17:20:23', null, '118 - C/PUJADES, 3', 'BIKE', '118', '7,8,45,149',
 'Sardenya', '3', 8, '08018', 41.392212, 2.187847, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8cc05dd7-4537-4755-a121-beefe7af6196', '2018-09-03 17:20:23', null, '119 - C/ SARDENYA, 178', 'BIKE', '119',
 '3,372,387,426', 'Sardenya', '178', 2, '08013', 41.396684, 2.182447, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8cfa0d46-833d-4e18-a0d3-4ce4e01027ec', '2018-09-03 17:20:23', null, '120 - C/ LEPANT, 278', 'BIKE', '120',
 '18,22,121,370', 'Lepant', '278', 2, '08025', 41.404666, 2.176515, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('7c7e7a92-205d-4e33-ad97-b0f719dfb2e3', '2018-09-03 17:20:23', null, '121 - C/ CASTILLEJOS, 258', 'BIKE', '121',
 '18,26,120,371', 'Castillejos', '258', 2, '08013', 41.406293, 2.178689, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('79790d43-712f-4beb-a15d-443cff7a1935', '2018-09-03 17:20:23', null, '122 - C/NÀPOLS, 344', 'BIKE', '122',
 '19,106,108,277', 'Nàpols', '344', 5, '08013', 41.405435, 2.16624, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('cdbe783b-2829-4d1a-862a-846206a60b59', '2018-09-03 17:20:23', null, '123 - C/ GIRONA, 142', 'BIKE', '123',
 '27,189,224,362', 'Girona', '142', 2, '08037', 41.398013, 2.166978, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('347772f6-3678-4272-a0fb-7e1215227666', '2018-09-03 17:20:23', null, '124 - NOVA BOCANA', 'BIKE', '124',
 '31,32,41,400', 'Passeig Joan de Borbó', 's/n', 1, '08003', 41.370297, 2.187808, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4752b345-c6bc-4ac1-a8b9-fa8a1df8f4f1', '2018-09-03 17:20:23', null, '125 - PG. MARíTIM, 31 B (ANNEXA A LA 12)',
 'BIKE', '125', '12,13,69,398', 'Passeig Maritim', '31', 1, '08003', 41.384426, 2.195595, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('845ad1f5-2a37-4e8a-8731-1290be9c8743', '2018-09-03 17:20:23', null, '126 - PG. DE COLOM /VIA LAIETANA', 'BIKE', '126',
 '37,115,377,402', 'Passeig de Colom', null, 1, '08002', 41.380641, 2.182243, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6e083221-5c1e-4c11-8e07-29a38f69ba51', '2018-09-03 17:20:23', null, '127 -C/ ARAGÓ, 661 /NAVAS DE TOLOSA', 'BIKE',
 '127', '103,104,128,238', 'Aragó', '661', 8, '08018', 41.412322, 2.19142, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e305b2c9-a6af-44d7-ac26-fdc17a88d05c', '2018-09-03 17:20:23', null, '128 - RAMBLA DE GUIPÚSCOA,43/FLUVIÀ', 'BIKE',
 '128', '127,130,135,238', 'Rambla Guipúscoa', '43', 8, '08020', 41.415581, 2.19581, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('24d91f74-57ce-4660-a09f-ff15918a9139', '2018-09-03 17:20:23', null, '129 - C/ MANSO, 46', 'BIKE', '129',
 '91,112,113,148', 'Manso', '46', 2, '08001', 41.37709, 2.16124, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('55b72a50-1a25-478e-b54c-ee20807486d4', '2018-09-03 17:20:23', null, '130 - RAMBLA DE GUIPÚSCOA, 103 /CANTÀBRIA',
 'BIKE', '130', '127,128,131,139', 'Rambla Guipúscoa', '103', 8, '08020', 41.419905, 2.201573, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ff40ba40-5f69-495b-a317-c313678864d6', '2018-09-03 17:20:23', null, '131 - RAMBLA DE GUIPÚSCOA, 158/ CA N''OLIVA',
 'BIKE', '131', '130,139,316,317', 'Rambla Guipúscoa', '158', 8, '08020', 41.422808, 2.206036, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ebce9ff0-8595-4a15-900f-f3ab3cf4368c', '2018-09-03 17:20:23', null, '132 - PL.VALENTÍ ALMIRALL', 'BIKE', '132',
 '42,103,133,141', 'Pl. Valentí Amirall', null, 8, '08018', 41.408439, 2.192173, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2d83e025-0adb-4f25-b7ed-6a91d7509c81', '2018-09-03 17:20:23', null, '133 - GRAN VIA DE LES CORTS CATALANES, 902',
 'BIKE', '133', '42,43,132,141', 'Gran Vía', '902', 8, '08018', 41.407411, 2.192819, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c06a3c2f-8e63-456a-a917-5066a37bf8e6', '2018-09-03 17:20:23', null, '134 - C/ BAC DE RODA, 157', 'BIKE', '134',
 '135,136,141,145', 'Bac de Roda', '157', 8, '08018', 41.411433, 2.198735, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('13a44b85-129a-4866-96d9-9183e72b2305', '2018-09-03 17:20:23', null, '135 - GRAN VIA DE LES CORTS CATALANES, 981',
 'BIKE', '135', '136,137,141', 'Gran Vía', '981', 8, '08018', 41.411908, 2.197936, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3939baae-c326-4c79-905a-5af862265141', '2018-09-03 17:20:23', null, '136 - GRAN VIA DE LES CORTS CATALANES, 1062',
 'BIKE', '136', '137,138,146', 'Gran Vía', '1062', 8, '08020', 41.414226, 2.201734, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('91a1d271-872a-42b2-8454-106a2569ff45', '2018-09-03 17:20:23', null, '137 - GRAN VIA DE LES CORTS CATALANES, 1041',
 'BIKE', '137', '130,136,138,146', 'Gran Vía, 1041/ Selva de Mar', '1041', 8, '08020', 41.414758, 2.201538, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a3f07e87-bd14-4dc7-bb08-b8bf2e9cad3c', '2018-09-03 17:20:23', null, '138 - GRAN VIA DE LES CORTS CATALANES, 1118',
 'BIKE', '138', '136,137,139,147', 'Gran Vía', '1118', 8, '08020', 41.416966, 2.205397, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('cbda1264-a80a-4051-a76f-89dc0a72337c', '2018-09-03 17:20:23', null, '139 - GRAN VIA DE LES CORTS CATALANES, 1131',
 'BIKE', '139', '130,131,138,147', 'Gran Vía', '1131', 8, '08020', 41.418035, 2.206023, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('89fd4a64-4091-4655-98b6-b330818d002a', '2018-09-03 17:20:24', null, '140 - C/ VILADOMAT, 122', 'BIKE', '140',
 '82,91,111,262', 'Viladomat', '122', 2, '08015', 41.38063, 2.15614, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('39ed977a-662b-49b2-99e6-6a5d3b0e5a2e', '2018-09-03 17:20:24', null, '141 - GRAN VIA DE LES CORTS CATALANES , 940',
 'BIKE', '141', '42,132,133,135', 'Gran Via', '940', 8, '08005', 41.40902, 2.194896, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ee5852ae-a42e-49a8-88b3-9f4985245f96', '2018-09-03 17:20:24', null, '142 - C/ SANCHO DE ÁVILA, 104- C/BADAJOZ',
 'BIKE', '142', '42,44,143,211', 'Sancho de Ávila', '104', 8, '08018', 41.400503, 2.192511, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d08e3b97-bb13-4767-9c6e-15c8608fb0cc', '2018-09-03 17:20:24', null, '143 - C/ SANCHO DE ÁVILA, 170 / LLACUNA', 'BIKE',
 '143', '42,144,152,153,428', 'Sancho de Ávila', '170', 8, '08018', 41.40325, 2.19606, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ba6fc3c7-91c5-44fd-a2a3-5eca945ecfd8', '2018-09-03 17:20:24', null, '144 - C/ CASTELLA, 28 / DIAGONAL', 'BIKE', '144',
 '42,143,150,286', 'Castella', '28', 8, '08018', 41.40562, 2.19764, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('66ef6c1a-03ab-48af-8688-86681c233e20', '2018-09-03 17:20:24', null, '145 - C/ PERE IV, 301 / FLUVIÀ', 'BIKE', '145',
 '135,146,150,156', 'Pere IV', '301', 8, '08019', 41.40982, 2.202904, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4a2cd105-ab5d-4981-8f24-554a5b8173b3', '2018-09-03 17:20:24', null, '146 - C/PERE IV, 464/C/JOSEP PLA', 'BIKE', '146',
 '136,137,138,145', 'Pere IV', '464', 8, '08020', 41.415191, 2.207111, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('16c96c41-ad27-492f-81a4-4b47714fa265', '2018-09-03 17:20:24', null, '147 - RAMBLA PRIM, 79', 'BIKE', '147',
 '146,157,158,159', 'Rambla Prim', '79', 8, '08019', 41.416018, 2.212658, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ab8e8db3-e1e4-4dc9-a013-38e2a7eb27c9', '2018-09-03 17:20:24', null, '148 - RONDA SANT PAU, 79', 'BIKE', '148',
 '70,113,388,415', 'Ronda Sant Pau', '79', 2, '08001', 41.378436, 2.163324, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('f738fe4e-88ae-40d2-8dd2-5ebbb30dade3', '2018-09-03 17:20:24', null, '149 - C/PUJADES, 57B', 'BIKE', '149',
 '45,48,118,409', 'Pujades', '57B', 8, '08005', 41.395905, 2.192958, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('116b6bfd-a777-47ee-9117-22a27c8ad088', '2018-09-03 17:20:24', null, '150 - C/ ESPRONCEDA,  124', 'BIKE', '150',
 '144,145,154,155', 'Espronceda', '124', 8, '08005', 41.406549, 2.203112, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('9aa4740d-f325-4d14-9cf8-3fda9cba51a4', '2018-09-03 17:20:24', null, '151 - C/ PALLARS, 182', 'BIKE', '151',
 '152,153,211,393,428', 'Pallars', '462', 8, '08018', 41.40065, 2.19719, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3e2d36a9-6a31-48a0-bf65-0149ccea5d49', '2018-09-03 17:20:24', null, '152 - C/ PUJADES 121', 'BIKE', '152',
 '143,149,153,393', 'Pujades', '121', 8, '08005', 41.39925, 2.197421, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('002656e8-437e-490e-9f83-4021a7d0955a', '2018-09-03 17:20:24', null, '153 - C/ PUJADES, 173/RAMBLA DEL POBLE NOU',
 'BIKE', '153', '152,154,165,393,428', 'Pujades', '173', 8, '08005', 41.401778, 2.200769, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('5e387832-7d3c-4408-95f0-34077caaf03f', '2018-09-03 17:20:24', null, '154 - C/ PUJADES, 191', 'BIKE', '154',
 '141,153,165,382', 'Pujades', '191', 8, '08005', 41.402454, 2.201656, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0815234b-bb94-4787-ae86-05e04482b4de', '2018-09-03 17:20:24', null, '155 - C/ PUJADES, 311/ FLUVIÀ', 'BIKE', '155',
 '150,156,162,382', 'Pujades', '311', 8, '08019', 41.406977, 2.207602, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1a4d9989-4ded-4393-b3e3-ecbc4c6ac218', '2018-09-03 17:20:24', null, '156 -C/ SELVA DE MAR, 46', 'BIKE', '156',
 '145,155,157,159', 'Diagonal', '46', 8, '08006', 41.409017, 2.20881, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('74166de7-8caa-430f-93f5-0377ae7b8cba', '2018-09-03 17:20:24', null, '157 - C/ LLULL, 465 - RBLA. PRIM', 'BIKE', '157',
 '35,147,158,159,160', 'C/ LLULL - RBLA. PRIM', '465', 8, '08019', 41.412947, 2.217819, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8d37bb4d-6542-45fb-ad5f-2edb91536826', '2018-09-03 17:20:24', null, '158 - RAMBLA DE PRIM, 19', 'BIKE', '158',
 '35,156,157,159,160', 'Rambla de Prim', '19', 8, '08019', 41.411741, 2.218546, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('94af81be-1e2f-45ec-bb51-93098f39da9d', '2018-09-03 17:20:24', null, '159 - AV. DIAGONAL, 26', 'BIKE', '159',
 '35,156,157,158,160', 'Avda. Diagonal', '26', 8, '08019', 41.410882, 2.216703, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('baca414d-1db3-45b1-80b0-c3fc7e21828b', '2018-09-03 17:20:24', null, '160 - AV. D''EDUARD MARISTANY, 1 /FORUM', 'BIKE',
 '160', '35,156,157,158,159', 'Avda. d''Eduard Maristany', '1', 8, '08019', 41.411026, 2.219377, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('902ae551-4a1d-47c3-98a9-b3e81b40b947', '2018-09-03 17:20:24', null, '161 - C/ RAMON TURRÓ, 91', 'BIKE', '161',
 '49,149,163,409', 'Ramon Turro', '91', 8, '08005', 41.395009, 2.196308, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('09745b85-8993-434f-b290-309b19c4d1fc', '2018-09-03 17:20:24', null, '162 - C/RAMON TURRÓ, 292', 'BIKE', '162',
 '155,166,167,168', 'Ramon Turro', '292', 8, '08019', 41.403908, 2.208436, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('32dd1409-402a-4706-a419-f4b001af8044', '2018-09-03 17:20:24', null, '163 - AV. ICÀRIA, 202', 'BIKE', '163',
 '49,117,161,172', 'Avda. Icaria', '202', 8, '08005', 41.3942, 2.20077, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1d7e1804-f3a5-43cb-8935-a09bfff41e5a', '2018-09-03 17:20:24', null, '164 - C/ INDEPENDÈNCIA, 379', 'BIKE', '164',
 '20,21,177,280', 'Independència', '379', 8, '08041', 41.41194, 2.178037, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('70b7f9e3-ce63-46c1-8f43-8417030d3b4a', '2018-09-03 17:20:24', null, '165 - C/ DEL DOCTOR TRUETA, 221', 'BIKE', '165',
 '153,154,166,173', 'Carrer del Doctor Trueta', '221', 8, '08005', 41.399196, 2.204253, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d1166195-58ce-4e62-83ca-433bae69dfd4', '2018-09-03 17:20:24', null, '166 - C/ BILBAO, 11', 'BIKE', '166',
 '162,165,173,174', 'Bilbao', '11', 8, '08005', 41.400533, 2.206539, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a71806bd-9c19-4cb2-bb39-0cce4db44c5a', '2018-09-03 17:20:24', null, '167 - C/ BAC DE RODA, 11', 'BIKE', '167',
 '162,166,168,176', 'Bac de Roda', '11', 8, '08005', 41.402561, 2.210538, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('414d46c7-d441-4877-bf67-3faf95f65ec3', '2018-09-03 17:20:24', null, '168 -SELVA DE MAR / PG. DE TAULAT', 'BIKE',
 '168', '162,167,176,178', 'Selva de Mar', '0', 8, '08019', 41.405358, 2.213677, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2a8211bb-1b79-483a-818b-5491dac9fb99', '2018-09-03 17:20:24', null, '169 - AV.LITORAL, 40 (ANNEXA A LA 170)', 'BIKE',
 '169', '11,170,172,397', 'Avda. Litoral', '40', 8, '08005', 41.389896, 2.200055, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ba01e129-6f55-4551-91d3-886efbe37e4d', '2018-09-03 17:20:24', null, '170 - AV.LITORAL, 40 (ANNEXA A LA 169)', 'BIKE',
 '170', '117,169,172,397', 'Avda. Litoral', '40', 8, '08005', 41.389732, 2.199934, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('57cca6e0-1b4b-4025-8f51-a57ef147951b', '2018-09-03 17:20:24', null, '171 - PG MARÍTIM DE LA NOVA ICÀRIA, 83', 'BIKE',
 '171', '163,169,170,172', 'Passeig Marítim de la Nova Icària', '83', 8, '08005', 41.391986, 2.203699, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d6a79e78-e5d0-42c8-9200-54ea4e4ea802', '2018-09-03 17:20:24', null, '172 - PG MARÍTIM DE LA NOVA ICÀRIA, 83', 'BIKE',
 '172', '163,169,170,171', 'Passeig Marítim de la Nova Icària', '83', 8, '08005', 41.391831, 2.203436, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('665bf55b-e4bc-48fa-82b6-fdb873b0dfd1', '2018-09-03 17:20:24', null, '173 - AV.LITORAL, 84', 'BIKE', '173',
 '166,171,174,190', 'Avda. Litoral', '84', 8, '08005', 41.398027, 2.208982, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d09bb098-6be0-4801-8603-c682e863ae7e', '2018-09-03 17:20:24', null, '174 - PG. DE GARCIA FÀRIA, 21/ESPRONCEDA',
 'BIKE', '174', '166,173,176,178', 'Passeig de Garcia Fària', '21', 8, '08005', 41.40061, 2.210461, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b80fcac0-272d-4f3b-86ee-27620817e723', '2018-09-03 17:20:24', null, '175 - C/ LLULL, 309', 'BIKE', '175',
 '155,156,162,167', 'Llull / Provençals', '309', 8, '08019', 41.40666, 2.20956, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('cac079da-a138-45b8-9d82-76519b673c7e', '2018-09-03 17:20:24', null, '176 - PG. DE GARCIA FÀRIA, 37/JOSEP FERRATER',
 'BIKE', '176', '167,168,174,178', 'Passeig de Garcia Fària', '37', 8, '08005', 41.402541, 2.212641, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3911dcee-73fb-454c-a76e-fe89f9600d50', '2018-09-03 17:20:24', null, '177 - C/ ROSSELLÓ, 557', 'BIKE', '177',
 '20,121,164,280', 'Rosselló', '557', 8, '08026', 41.411089, 2.181119, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0cf45e18-82ef-4723-a77d-7468f992d6da', '2018-09-03 17:20:24', null, '178 - PG. DE GARCIA FÀRIA, 85', 'BIKE', '178',
 '162,166,167,168', 'Passeig de Garcia Fària', '85', 8, '08019', 41.405389, 2.216212, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('77f1de86-ac1f-46b1-b023-607e281462d9', '2018-09-03 17:20:24', null, '179 - PG. ZONA FRANCA, 244', 'BIKE', '179',
 '184,351,352,404', 'Pg. Zona Franca', '244', 3, '08028', 41.363511, 2.13677, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('56e35878-2b0a-49e3-8e9a-dd9ef066f9f7', '2018-09-03 17:20:24', null,
 '180 - GRAN VIA DE LES CORTS CATALANES/MOSSÈN AMADE', 'BIKE', '180', '179,181,182,183', 'Gran Via', '181', 3, '08014',
 41.36778, 2.13926, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('cc777552-a914-4a43-b8e3-4d6dc1b93faa', '2018-09-03 17:20:24', null,
 '181 - GRAN VIA DE LES CORTS CATALANES/MOSSÈN AMAD', 'BIKE', '181', '179,180,182,183', 'Gran Via', '180', 3, '08014',
 41.36766, 2.13911, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('7ea2374c-4b54-461f-b5c4-567c516807a3', '2018-09-03 17:20:24', null, '182 - GRAN VIA DE LES CORTS CATALANES , 273',
 'BIKE', '182', '96,180,183,420', 'Gran Via', '273', 3, '08014', 41.371455, 2.143882, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ee9d8e7e-e112-4a65-a530-fa40c9726d60', '2018-09-03 17:20:24', null, '183 - C/ GAVÀ, 1', 'BIKE', '183',
 '181,182,185,420', 'Gavà', '1', 3, '08014', 41.372338, 2.141875, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('5ad709fc-56e1-4c5a-9fdf-3d93bf523740', '2018-09-03 17:20:24', null, '184 - C/ QUETZAL, 22-24', 'BIKE', '184',
 '179,180,185,404', 'Quetzal', '22', 3, '08014', 41.367504, 2.134088, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('5eb0a436-2d5f-4455-9ff0-d3815bdd0002', '2018-09-03 17:20:24', null, '185 - C/GAVÀ, 81', 'BIKE', '185',
 '180,181,184,404', 'Gavà', '81', 3, '08014', 41.37046, 2.138994, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a1d904a1-6c4c-48e9-b59e-731a3b3eafa9', '2018-09-03 17:20:24', null, '186 - C/CONSELL DE CENT, 6', 'BIKE', '186',
 '95,96,210,420', 'Consell de Cent', '6', 3, '08014', 41.375571, 2.143812, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('26991b27-1a5f-469d-a286-ff0b276ff476', '2018-09-03 17:20:24', null, '187 - C/ DE SANT PAU, 89 - 97', 'BIKE', '187',
 '50,54,416,427', 'Carrer de Sant Pau', '89', 1, '08001', 41.376858, 2.169811, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('bdff736f-974d-4f71-85ef-65cc5a9bfc41', '2018-09-03 17:20:24', null, '188 - PG. SANT ANTONI/PL. SANTS', 'BIKE', '188',
 '210,313,354,421', 'Pl. Sants (Ps. S. Antoni)', '0', 3, '08028', 41.375471, 2.135543, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3e90f950-7deb-44b9-bf81-d08ec5e89c9f', '2018-09-03 17:20:24', null, '189 - C/ BRUC, 130', 'BIKE', '189',
 '25,27,123,224', 'Bruc', '130', 2, '08037', 41.396918, 2.166163, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('61144ee0-040e-4715-8515-857b42653e2c', '2018-09-03 17:20:24', null, '190 - AV. LITORAL, 72', 'BIKE', '190',
 '165,171,172,173', 'Avinguda Litoral', '72', 8, '08005', 41.39606, 2.207803, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d8093661-ec4d-4bff-87a6-aa9aca203916', '2018-09-03 17:20:24', null, '191 -C/ ROCAFORT, 167', 'BIKE', '191',
 '81,87,111,384', 'Rocafort', '167', 2, '08015', 41.382564, 2.149094, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('7ef02f98-fc55-498f-907d-ac284af42b41', '2018-09-03 17:20:24', null, '192 - C/ JOAN GÜELL, 50', 'BIKE', '192',
 '188,193,194,314', 'Joan Güell', '50', 3, '08028', 41.378629, 2.133467, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('df255bd6-cd25-410d-998a-00f57eb92f95', '2018-09-03 17:20:24', null, '193 - C/FÍGOLS, 1', 'BIKE', '193',
 '192,194,199,312', 'Figols', '1', 7, '08028', 41.381311, 2.128912, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a32130d4-8b6e-4bda-ab44-753327ba196b', '2018-09-03 17:20:25', null, '194 - C/JOAN GÜELL, 98', 'BIKE', '194',
 '192,193,196,200', 'Joan Güell', '98', 7, '08028', 41.381013, 2.132319, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('478a5186-c90e-4b23-9f7d-9ec3f5e2d3ff', '2018-09-03 17:20:25', null, '195 - C/VALLESPIR, 130', 'BIKE', '195',
 '192,194,196,367', 'Vallespir', '130', 7, '08014', 41.381888, 2.135433, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('9e7b38a0-4ec9-459a-a6dd-6055e2f8deb7', '2018-09-03 17:20:25', null, '196- C/ BERLÍN, 38', 'BIKE', '196', '197,201',
 'Berlín', '38', 3, '08029', 41.383241, 2.139363, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('79de9b10-8bb1-46b0-89fc-75c260900497', '2018-09-03 17:20:25', null, '197 - C/GELABERT, 1', 'BIKE', '197',
 '75,196,201,367', 'Gelabert', '1', 7, '08029', 41.387295, 2.141539, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c0e667e6-492d-4053-8759-345856a1fb7a', '2018-09-03 17:20:25', null, '198 - C/ VALLESPIR, 194', 'BIKE', '198',
 '196,200,201,205', 'Vallespir', '194', 7, '08014', 41.384426, 2.133682, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('62498146-0602-4e92-a102-e1f8f53b2dbf', '2018-09-03 17:20:25', null, '199 - C/ MEJÍA LEQUERICA, 2', 'BIKE', '199',
 '193,200,202,312', 'Mejía Lequerica', '2', 7, '08028', 41.38182, 2.126933, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c8d039d9-9f07-4519-b3c7-b07544cc2035', '2018-09-03 17:20:25', null, '200 - C/ CAN BRUIXA, 1', 'BIKE', '200',
 '193,194,196,198', 'Can bruixa', '1', 7, '08028', 41.383756, 2.131273, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1508fe43-e5be-4357-b6f1-3846011e61eb', '2018-09-03 17:20:25', null, '201 -C/ NUMÀNCIA, 136', 'BIKE', '201',
 '198,206,207,208', 'Numància', '136', 7, '08029', 41.387787, 2.134341, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('972b9fa7-7523-413f-93d8-a3fb82226196', '2018-09-03 17:20:25', null, '202 - C/ DE LES CORTS, 20', 'BIKE', '202',
 '199,200,203,205', 'Carrer de les Corts', '20', 7, '08028', 41.385331, 2.128737, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('deedbaf0-e874-40a6-a546-add7c2cfc680', '2018-09-03 17:20:25', null, '203 - AV. DIAGONAL, 668', 'BIKE', '203',
 '204,205,212,284', 'Avda. Diagonal', '664', 7, '08034', 41.388742, 2.128503, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e3218ff5-50a4-477f-92e8-a92622cded3e', '2018-09-03 17:20:25', null, '204 - AV. DIAGONAL, 664', 'BIKE', '204',
 '202,203,205,212', 'Avda. Diagonal', '668', 7, '08034', 41.388011, 2.125593, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('9348c3a9-8ce2-49e1-bc0b-77b4cc0374bb', '2018-09-03 17:20:25', null, '205 - C/ EUROPA, 25', 'BIKE', '205',
 '198,202,203,284', 'Europa', '25', 7, '08028', 41.387465, 2.130838, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('37963748-570c-4802-bffd-006f2b44c94d', '2018-09-03 17:20:25', null, '206 - AV. DIAGONAL, 650', 'BIKE', '206',
 '201,207,208,284', 'Avda. Diagonal', '650', 7, '08017', 41.389845, 2.13284, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a4c1a754-6edb-46e8-80c0-dfb991ea6593', '2018-09-03 17:20:25', null, '207 - AV. DIAGONAL, 634', 'BIKE', '207',
 '201,204,206,208', 'Avda. Diagonal', '634', 7, '08017', 41.390828, 2.136665, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('39de566a-e07e-4107-bd2c-8995a64b4d7a', '2018-09-03 17:20:25', null, '208 - AV. DIAGONAL, 630', 'BIKE', '208',
 '201,206,207,366', 'Avda. Diagonal', '630', 6, '08017', 41.391451, 2.139116, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('48acf694-6b28-4502-a7b6-d8660bed180b', '2018-09-03 17:20:25', null, '209 - C/ DIPUTACIÓ, 200', 'BIKE', '209',
 '71,78,84,261', 'Diputació', '200', 2, '08011', 41.385755, 2.161004, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1521c875-e7c0-4e62-8d6e-88fcb2b6522a', '2018-09-03 17:20:25', null, '210 - C/VILARDELL, 18', 'BIKE', '210',
 '183,185,186,421', 'Vilardell', '18', 3, '08014', 41.37453, 2.142356, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('462658cd-a4c9-415a-8f8a-363b6967f0d6', '2018-09-03 17:20:25', null, '211 - C/SANCHO DE ÁVILA, 60-64', 'BIKE', '211',
 '16,44,48,142', 'Sancho de Ávila', '60', 8, '08018', 41.398848, 2.190291, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e193cb9b-37c9-485b-a201-00694b584818', '2018-09-03 17:20:25', null, '212 -AV. SARRIÀ, 163', 'BIKE', '212',
 '203,206,284,325', 'Av. Sarrià', '163', 7, '08017', 41.39239, 2.130945, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e15d5cec-7025-41d4-921d-a5d46dd475bb', '2018-09-03 17:20:25', null, '213 - C/ SANTA FE DE NOU MÈXIC, 2', 'BIKE',
 '213', '207,208,214,215', 'Sant Fe de Nou Mèxic', '2', 6, '08017', 41.393783, 2.135078, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('958ae02f-14ff-4ec6-beb0-bc8d674dee93', '2018-09-03 17:20:25', null, '214 - C/ JOSÉ DE AGULLÓ, 8', 'BIKE', '214',
 '207,208,212,213', 'José de Agulló', '19', 6, '08017', 41.395251, 2.133541, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('bc393851-6185-4d87-8090-bc53424550de', '2018-09-03 17:20:25', null, '215 - C/ GANDUXER, 29', 'BIKE', '215',
 '102,213,214,324', 'Carrer de Ganduxer', '29', 6, '08021', 41.39412, 2.138146, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b387146a-a62b-491d-8d62-6067178de9e9', '2018-09-03 17:20:25', null, '216 - C/ MADRAZO, 131', 'BIKE', '216',
 '101,217,219,319', 'Madrazo', '131', 6, '08021', 41.396809, 2.144534, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('96d50f3a-6fd8-4c24-ac2b-1f9ef56c9473', '2018-09-03 17:20:25', null, '217 - C/ RECTOR UBACH, 24', 'BIKE', '217',
 '102,216,219,319', 'Rector Ubach', '24', 6, '08021', 41.398463, 2.143924, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2308638b-dbee-4dd2-b161-97c9a3f53bf6', '2018-09-03 17:20:25', null, '218 - C/CONSELL DE CENT, 566', 'BIKE', '218',
 '30,43,369,371', 'Consell de Cent', '566', 2, '08013', 41.404114, 2.183203, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1133cca1-2ffd-4acc-8acd-40ff5cf09cc8', '2018-09-03 17:20:25', null, '219 - C/LAFORJA, 74-76', 'BIKE', '219',
 '107,216,217,220', 'Carre Laforja', '74', 6, '08021', 41.397812, 2.147585, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3572e8e8-78c7-446b-9e4c-c3fee4b76f78', '2018-09-03 17:20:25', null, '220 - C/ TUSET, 19', 'BIKE', '220',
 '68,88,107,219', 'Tuset', '19', 6, '08006', 41.396229, 2.151482, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('dd6bf50f-e097-42a7-92fc-6e2e0be70eea', '2018-09-03 17:20:25', null, '221 - GRAN DE GRÀCIA, 155 (METRO FONTANA)',
 'BIKE', '221', '107,222,229,230', 'Gran de Gràcia', '155', 5, '08012', 41.402535, 2.152519, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3118c46a-0de9-415a-9275-d0b0ba6fba38', '2018-09-03 17:20:25', null, '222 - C/ DEL CANÓ, 1', 'BIKE', '222',
 '107,221,226,229', 'Carrer del Canó', '1', 5, '08012', 41.40124, 2.157483, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('121dc5c3-c575-4853-8fa4-e40bf506c919', '2018-09-03 17:20:25', null, '223 - C/ DE BONAVISTA, 14', 'BIKE', '223',
 '68,224,225,374', 'Carrer de Bonavista', '14', 5, '08012', 41.398311, 2.159865, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1e84053d-ddc6-42ed-b996-c607e4aeb4c3', '2018-09-03 17:20:25', null, '224- C /GIRONA, 176', 'BIKE', '224',
 '27,108,123,189', 'Girona', '176', 2, '08036', 41.399945, 2.164389, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('15c8dbba-5d29-448e-b26c-2b8d20ef8119', '2018-09-03 17:20:25', null, '225 - C/MALLORCA, 84', 'BIKE', '225',
 '83,87,89,191', 'Mallorca', '84', 2, '08012', 41.38482, 2.15057, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6b3d41dc-cbc2-4c64-a8bc-c55349da7ce6', '2018-09-03 17:20:25', null, '226 - C/MONTMANY, 1', 'BIKE', '226',
 '106,108,122,231', 'Montmany', '1', 5, '08012', 41.403465, 2.161096, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2613817a-4fd4-40e2-81d9-a454dc3ff5ff', '2018-09-03 17:20:25', null, '227 - C/ DEL TORRENT DE LES FLORS, 102', 'BIKE',
 '227', '106,228,231', 'Torrent de Les Flors', '102', 5, '08024', 41.407837, 2.158678, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b084f650-d64e-410f-9e80-e0519304729f', '2018-09-03 17:20:25', null, '228 - PL.DEL NORD, 5', 'BIKE', '228',
 '106,227,229,230', 'Pl. Del Nord', '5', 5, '08024', 41.40694, 2.155794, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0b7afabb-78ed-457b-b26c-aa2231ab9c27', '2018-09-03 17:20:25', null, '229 - C/ DE LA SANTACREU, 2 (PL.DE LA VIRREINA)',
 'BIKE', '229', '106,226,227,228', 'Carrer de la Santacreu', '2', 5, '08024', 41.405107, 2.156874, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('fef3c8e9-7910-4b28-bff1-3e17ed20920d', '2018-09-03 17:20:25', null, '230 - C/ DE NIL FABRA, 16-20', 'BIKE', '230',
 '221,222,228,229', 'C. De Nil Fabra', '16', 5, '08012', 41.405986, 2.151633, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('981af9c5-74f0-4f76-a072-707110b37702', '2018-09-03 17:20:25', null, '231- C/PI I MARGALL, 38', 'BIKE', '231',
 '106,122,227,276', 'Pi i Margall', '38', 5, '08025', 41.407202, 2.163476, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('21a5dcd6-5662-4732-ac67-e46bf88fbbeb', '2018-09-03 17:20:25', null, '232 - C/VILÀ I VILÀ, 45', 'BIKE', '232',
 '50,233,234,427', 'Vilà i Vilà', '45', 3, '08004', 41.373509, 2.171002, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3fa8a1e1-8979-4727-ba8d-48ae047d9497', '2018-09-03 17:20:25', null, '233 - C/NOU DE LA RAMBLA, 164', 'BIKE', '233',
 '50,232,234,427', 'Nou de la Rambla', '164', 3, '08004', 41.371965, 2.166871, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ab17de1f-a942-4dbc-97cb-b096b0db2bc2', '2018-09-03 17:20:25', null, '234 - PG. DE L''EXPOSICIÓ, 30 /BLASCO GARAY',
 'BIKE', '234', '85,233,235,236', 'Passeig de l''Exposició', '30', 3, '08004', 41.371515, 2.162166, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2de67d35-f287-4c57-8238-6dd3cebabc92', '2018-09-03 17:20:25', null, '235 - AV. PARAL.LEL, 98', 'BIKE', '235',
 '85,129,234,236', 'Paral.lel', '98', 2, '08015', 41.375065, 2.165839, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3e4ff1e2-558e-4a87-9e22-ab279c447dc4', '2018-09-03 17:20:25', null, '236 - AV. PARAL.LEL, 194', 'BIKE', '236',
 '85,94,235,237', 'Avinguda Paral.lel', '194', 3, '08015', 41.375127, 2.152769, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('9a2206e9-29fd-407d-b01b-b2675777d91a', '2018-09-03 17:20:25', null, '237 - C/ RIUS I TAULET, 4', 'BIKE', '237',
 '85,93,234,236', 'Rius i Taulet', '4', 3, '08004', 41.372891, 2.154471, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6499acd0-b638-4e0c-ab21-87d9a75b22b7', '2018-09-03 17:20:25', null, '238 - C/ ESPRONCEDA, 298', 'BIKE', '238',
 '127,240,248,289', 'Espronceda', '298', 10, '08027', 41.415684, 2.190986, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4d72a3c7-1e4a-4659-bc52-e30c74e6343b', '2018-09-03 17:20:26', null, '239 - C/ INDÚSTRIA, 329', 'BIKE', '239',
 '240,241,248,315', 'Indústria', '329', 10, '08027', 41.417323, 2.184534, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0cc99be5-c471-40b0-8aa7-7009ad45c303', '2018-09-03 17:20:26', null, '240 - C/ JOSEP ESTIVILL, 32', 'BIKE', '240',
 '128,238,248,289', 'Josep Estivill', '32', 10, '08027', 41.417763, 2.187558, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6c3fcda5-9b30-456c-aed9-8e93c99480a7', '2018-09-03 17:20:26', null, '241 - C/ TEODOR LLORENTE, 2', 'BIKE', '241',
 '239,240,248,315', 'Teodor Llorente', '2', 4, '08041', 41.419337, 2.180482, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3aa11e3e-043d-4cde-9492-71dbfadb2d85', '2018-09-03 17:20:26', null, '242 - C/ RAMON ALBÓ, 1', 'BIKE', '242',
 '241,243,244,291', 'Ramon Albó', '1', 10, '08027', 41.424451, 2.177284, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a8948798-ca88-4b16-a070-526fde043ed6', '2018-09-03 17:20:26', null, '243 - C/ ALEXANDRE GALÍ 1-5', 'BIKE', '243',
 '241,242,244,247', 'Alenxadre Galí', '1', 10, '08027', 41.423939, 2.181298, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('f13db5a1-4d25-4508-83d3-5902920e8eeb', '2018-09-03 17:20:26', null, '244 - C/ FELIP II, 214', 'BIKE', '244',
 '242,243,251,300', 'Felip II', '214', 10, '08027', 41.426896, 2.178511, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('167c92fc-36ad-4510-9ba7-a93ba60de979', '2018-09-03 17:20:26', null, '246 - C/ GARCILASO, 77', 'BIKE', '246',
 '247,249,250,251', 'Garcilaso', '77', 10, '08027', 41.422844, 2.186637, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ebcb1722-496b-49ec-9244-2bc96d00d9b9', '2018-09-03 17:20:26', null, '247 - C/ FELIPE II, 112', 'BIKE', '247',
 '241,243,246,251', 'Felipe II', '112', 10, '08027', 41.421992, 2.184806, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4dabfd27-1cad-4977-b455-aa0d98dda062', '2018-09-03 17:20:26', null, '248 - C/ PALÈNCIA, 31', 'BIKE', '248',
 '128,238,240,423', 'Palència', '31', 10, '08027', 41.418208, 2.190374, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4797a1b7-4540-4652-8f99-210f9263bedb', '2018-09-03 17:20:26', null, '249 - C/AÇORES,1-3 / VALLÈS I RIBOT', 'BIKE',
 '249', '246,250,251,391', 'Açores', '1', 10, '08027', 41.425216, 2.188997, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('af5b125b-4973-4151-a750-0753d7799a04', '2018-09-03 17:20:26', null, '250 - C/PORTUGAL, 3', 'BIKE', '250',
 '249,252,253,254', 'Portugal', '3', 10, '08027', 41.425905, 2.19115, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d70b1c95-392b-46b9-a389-569d1a117868', '2018-09-03 17:20:26', null, '251 - C/ CARDENAL TEDESCHINI, 13', 'BIKE', '251',
 '243,246,247,249', 'Cardenal Tedeschini', '13', 10, '08027', 41.425405, 2.185226, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('5049091c-7747-4012-8148-1c7dec324cbb', '2018-09-03 17:20:26', null, '252 -RAMBLA DE L''ONZE DE SETEMBRE, 31', 'BIKE',
 '252', '249,250,254,391', 'Rambla Onze de Setembre', '31', 10, '08030', 41.429953, 2.193185, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('36535b80-36c9-4c3f-ad80-2e8e48d4f129', '2018-09-03 17:20:26', null, '253 - C/ ONZE DE SETEMBRE, 37-39', 'BIKE', '253',
 '250,252,254', 'Onze de Setembre', '37', 10, '08030', 41.429977, 2.191821, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c220d02b-e308-4747-b265-b0113586cc6e', '2018-09-03 17:20:26', null, '254 - RAMBLA DE L''ONZE DE SETEMBRE, 69', 'BIKE',
 '254', '250,252,253,255', 'Gran de Sant Andreu', '69', 10, '08030', 41.429985, 2.190163, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a05b95e9-9e39-4711-be49-15ca176827a7', '2018-09-03 17:20:26', null, '255 - C/ IRLANDA, 11-21', 'BIKE', '255',
 '253,254,274', 'Irlanda', '11', 10, '08030', 41.431183, 2.185852, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2768d622-c10a-4d86-85e6-3680c80d64d5', '2018-09-03 17:20:26', null, '256 - C/ MALATS, 28-30', 'BIKE', '256',
 '255,259,285', 'Malats', '28', 10, '08030', 41.435998, 2.189524, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d913917b-4f68-4d36-a28c-3db5c4c0103d', '2018-09-03 17:20:26', null, '257 - C/ SANT ADRIÀ, 2-8', 'BIKE', '257',
 '253,254,255,256', 'Sant Adrià', '2', 10, '08030', 41.433897, 2.189614, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('33a6c590-c8e4-4852-be63-ded008bebed8', '2018-09-03 17:20:26', null, '258 - C/ FENANDO PESSOA, 41', 'BIKE', '258',
 '256,259,263', 'Fernando Pessoa', '41', 10, '08030', 41.442167, 2.193032, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3b8cf57c-e9d2-4d83-8078-df43f770f288', '2018-09-03 17:20:26', null, '259 - C/ DE BARTRINA, 14', 'BIKE', '259',
 '256,258,267', 'Carrer de Bartrina', '14', 10, '08030', 41.439109, 2.185818, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('21e1de5b-64af-45df-ac55-d68a6ad22bf5', '2018-09-03 17:20:26', null, '260 - PL. DE L''ESTACIÓ, 6', 'BIKE', '260',
 '256,263,264', 'Plaça de l''Estació', '6', 10, '08030', 41.43618, 2.192952, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('512659b2-c13f-4716-8e0a-8c9c90869fc7', '2018-09-03 17:20:26', null, '261 -C/ VILLARROEL, 39', 'BIKE', '261',
 '70,71,84,90', 'Villarroel', '39', 2, '08011', 41.382206, 2.160644, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e181642a-a6f8-456a-9fca-7c1b44f31848', '2018-09-03 17:20:26', null, '262 -C/ ROCAFORT, 103', 'BIKE', '262',
 '81,82,111,191', 'Rocafort', '103', 2, '08015', 41.379821, 2.152496, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3d9b5f8c-795b-4f5e-bde0-d598bbaf5be5', '2018-09-03 17:20:26', null, '263 - PG. TORRAS I BAGES,29', 'BIKE', '263',
 '256,260,264', 'Pg.Torras i Bages', '29', 10, '08030', 41.437814, 2.191039, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('f7a881e9-5788-486a-a6fc-a7adab298030', '2018-09-03 17:20:26', null,
 '264 - C/REPÚBLICA DOMINICANA,25(CENTRE COMERCIAL)', 'BIKE', '264', '263,267,268,344', 'República Dominicana', '25',
 10, '08030', 41.439949, 2.197033, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8d0e4e05-0ada-4dfd-8609-fc5b7aa01ec4', '2018-09-03 17:20:26', null, '265 - C/ CASANOVAS,67', 'BIKE', '265',
 '80,84,110,209', 'Casanovas', '67', 2, '08011', 41.385397, 2.158743, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d78e9b49-66a9-4a36-a85c-4b38869283ec', '2018-09-03 17:20:26', null, '266 - C/ CONCEPCIÓ ARENAL, 176', 'BIKE', '266',
 '263,264,268,344', 'Concepció Arenal', '176', 10, '08027', 41.426841, 2.184238, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1a5bb26d-e654-4057-ad3b-47ce76ef3c15', '2018-09-03 17:20:26', null, '267 - PG. TORRAS I BAGES, 129', 'BIKE', '267',
 '258,263,264,268', 'Passeig Torras i Bages', '129', 10, '08030', 41.443395, 2.190623, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('7e654829-4881-4e98-b169-6ca3840aad92', '2018-09-03 17:20:26', null, '268 - C/ FERNANDO PESSOA, 72', 'BIKE', '268',
 '263,264,267,271', 'Fernando Pessoa', '72', 10, '08030', 41.445705, 2.192892, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6a18b99d-aa1c-4c88-97d8-d52819fb12be', '2018-09-03 17:20:26', null, '269 - VIA BARCINO, 121', 'BIKE', '269',
 '264,268,270,271', 'Via Barcino', '121', 10, '08033', 41.448128, 2.192826, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b04c1056-ddf1-4a82-9a6b-b1f0c5fc9740', '2018-09-03 17:20:26', null, '270 - CRTA. DE RIBES, 77 (TRINITAT VELLA)',
 'BIKE', '270', '267,268,269,271', 'Crta. de Ribes (Trinitat Vella)', '77', 10, '08033', 41.448628, 2.18976, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('5796ed12-bb80-417d-a564-455685ed99bf', '2018-09-03 17:20:26', null, '271 - VIA BARCINO, 69', 'BIKE', '271',
 '267,268,269,270', 'Via Barcino', '69', 10, '08033', 41.450634, 2.192335, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('eac604c1-e501-45d8-b86a-81b09dfd5d31', '2018-09-03 17:20:26', null, '272 -C/ CONCEPCIÓ ARENAL, 281', 'BIKE', '272',
 '255,273,274,298', 'Concepció Arenal', '281', 10, '08030', 41.432552, 2.18429, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('9a47c61c-ca7a-4780-bd01-613ab61b582a', '2018-09-03 17:20:26', null,
 '273 - AV. MERIDIANA/PG. FABRA I PUIG (SANT ANDREU)', 'BIKE', '273', '255,272,274,275', 'Avda. Meridiana', '404', 10,
 '08030', 41.430404, 2.183382, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('257901c4-73e5-4b46-931a-bd7827c5cd37', '2018-09-03 17:20:26', null, '274 - RAMBLA FABRA I PUIG, 67', 'BIKE', '274',
 '254,255,272,273', 'Rambla Fabra i Puig', '67', 10, '08030', 41.430071, 2.18473, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('769b7ecc-91a8-4b24-9db8-5a4d71d29563', '2018-09-03 17:20:26', null, '275 - AV. RIO DE JANEIRO 3', 'BIKE', '275',
 '272,273,274,298', 'Rio de Janeiro', '3', 9, '08016', 41.430693, 2.182225, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ecb2abfc-e1a4-40aa-8157-4157f1222a9b', '2018-09-03 17:20:26', null,
 '276 - PLAÇA ALFONS X EL SAVI / RONDA DEL GUINARDO', 'BIKE', '276', '231,277,278,318',
 'Plaça Alfons X el Savi / Ronda del Guinardó', null, 4, '08025', 41.412163, 2.165275, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1824a0ca-a752-4905-aee8-6f86bc339f44', '2018-09-03 17:20:26', null, '277 -  TRAVESSERA DE GRÀCIA 328', 'BIKE', '277',
 '28,122,123,231', 'Travessera de Gràcia', '328', 4, '08025', 41.408284, 2.16905, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2675035c-341b-4a1d-80f1-e989c755bf71', '2018-09-03 17:20:26', null, '278 - TRAVESSERA DE GRÀCIA, 368', 'BIKE', '278',
 '20,21,28,277', 'Travessera de Gràcia', '368', 4, '08025', 41.409815, 2.171621, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4d3f77b9-622c-4b6a-86b4-68e9447816a2', '2018-09-03 17:20:26', null, '279 - C/ MAS CASANOVAS, 137', 'BIKE', '279',
 '278,280,281,318', 'Mas Casanovas', '137', 4, '08041', 41.415951, 2.174564, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('7a5ae4ff-06d0-4583-9fcf-26a56d5905ef', '2018-09-03 17:20:26', null, '280 - C/ SANT ANTONI Mª CLARET, 290', 'BIKE',
 '280', '20,21,164,239', 'Sant Antoni Mª Claret', '290', 4, '08041', 41.413986, 2.177842, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('aa1b2ef2-5725-424f-a8ef-85e4f6dd130f', '2018-09-03 17:20:26', null, '281 - C/D''ESCORNALBOU,51', 'BIKE', '281',
 '241,242,243,279', 'Escornalbou', '51', 4, '08041', 41.418088, 2.176313, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('29fe23f4-3994-44e7-b398-26dfc7f1e6d2', '2018-09-03 17:20:27', null, '282 - PG. FONT D''EN FARGAS, 1', 'BIKE', '282',
 '291,292,293,295', 'Font d''en Fargas', '1', 4, '08031', 41.427561, 2.166022, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6c102a27-4249-41d4-be8c-3854bbcdd580', '2018-09-03 17:20:27', null, '283 - C/ FULTON, 1', 'BIKE', '283',
 '282,291,292,293', 'Carrer Fulton', '1', 4, '08032', 41.42968, 2.16157, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2707d997-206e-4bee-bd0c-85db650d3fb1', '2018-09-03 17:20:27', null, '284 - AV. DIAGONAL, 652', 'BIKE', '284',
 '203,205,206,212', 'Ada. Diagonal', '652', 7, '08034', 41.389503, 2.131454, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6dbde047-e93c-441b-9d01-c66cea7f090b', '2018-09-03 17:20:27', null, '285 - C/MALATS, 98-100', 'BIKE', '285',
 '256,259,272', 'Malats', '98', 10, '08030', 41.436708, 2.186059, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0c968ba1-751e-4ee9-8c07-87cd08def16f', '2018-09-03 17:20:27', null, '286 - C/ BOLÍVIA, 76', 'BIKE', '286',
 '42,44,142,143', 'Bolívia', '76', 8, '08018', 41.403103, 2.191428, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0ab5b4a2-7736-4cee-a5fa-b85470d19f94', '2018-09-03 17:20:27', null, '287 - GRAN VIA DE LES CORTS CATALANES, 632',
 'BIKE', '287', '61,64,66,406', 'Gran Via', '632', 2, '08007', 41.389171, 2.168113, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a1d7d6ef-67fb-476f-b561-7c6991911282', '2018-09-03 17:20:27', null, '288 - PL. VIRREI AMAT', 'BIKE', '288',
 '244,291,292,293', 'Pl. Virrei Amat', null, 9, '08031', 41.429636, 2.174487, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('181e30f8-a65f-42b3-89d2-71fa2502986a', '2018-09-03 17:20:27', null, '289 - C/MÚRCIA, 64', 'BIKE', '289',
 '127,238,240,248', 'Múrcia', '64', 10, '08027', 41.416828, 2.191022, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4028fe46-d10e-47df-9a66-f1960475af15', '2018-09-03 17:20:27', null, '290 - PL. DELS JARDINS D''ALFÀBIA, 1', 'BIKE',
 '290', '294,295,299,301', 'Plaça dels Jardins d''Alfàbia', '1', 9, '08016', 41.437094, 2.174047, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('7834ba5f-8e9f-4c75-942e-fdb4eae6019b', '2018-09-03 17:20:27', null, '291 - C/ CUBELLES, 2', 'BIKE', '291',
 '242,244,282,292', 'Cubelles', '2', 9, '08031', 41.425897, 2.17505, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('804a25be-6350-47ae-ae9d-131b9ad99f61', '2018-09-03 17:20:27', null, '292 - C/ AMILCAR, 1', 'BIKE', '292',
 '282,291,293,300', 'Amilcar', '1', 9, '08031', 41.430036, 2.171974, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('648d8bb1-4f17-46e2-9221-e3f82e23973c', '2018-09-03 17:20:27', null, '293 - C/ GRANOLLERS, 1', 'BIKE', '293',
 '282,291,292,295', 'Granollers', '1', 4, '08031', 41.428388, 2.163101, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8a89c3be-0a45-41fb-a45a-63635a972ee8', '2018-09-03 17:20:27', null, '294 - SEU DEL DISTRICTE (NOU BARRIS)', 'BIKE',
 '294', '290,295,299,301', 'Seu del Districte (Nou Barris)', null, 9, '08042', 41.436373, 2.170678, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3364635a-0cf4-4254-b9e1-f2bc995ce084', '2018-09-03 17:20:27', null, '295 - C/ SANT ISCLE, 60', 'BIKE', '295',
 '282,292,294,301', 'Sant Iscle', '60', 9, '08031', 41.43345, 2.1715, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c9b101ef-44eb-4a15-958d-97bb583b3c62', '2018-09-03 17:20:27', null, '296 - C/ DE ROSSELLÓ I PORCEL, 1 - AV.MERIDIANA',
 'BIKE', '296', '259,272,285,298', 'Carrer de Rosselló i Porcel', '1', 9, '08016', 41.436505, 2.183877, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('60183eec-154f-4808-82e6-759a50f51966', '2018-09-03 17:20:27', null, '297 -  C/ TURÓ BLAU, 1-3', 'BIKE', '297',
 '290,296,298,299', 'Carrer Turó Blau', '1', 9, '08016', 41.438864, 2.176822, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b58b533d-937b-4f50-8469-3804a7df429e', '2018-09-03 17:20:27', null, '298 - C/ ANDREU NIN, 22', 'BIKE', '298',
 '275,296,300', 'Andreu Nin', '22', 9, '08016', 41.43463, 2.181747, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('db334247-cf5c-4527-8199-71b6d14cc20f', '2018-09-03 17:20:27', null, '299 - C/ DE L''ESCULTOR ORDÓÑEZ, 55', 'BIKE',
 '299', '294,295,297,301', 'Carrer de l''Escultor Ordóñez', '55', 9, '08016', 41.433965, 2.175199, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('739e8a9f-764e-4e1c-9bd9-48c8ac915b26', '2018-09-03 17:20:27', null, '300 - C/ DE MALADETA, 1', 'BIKE', '300',
 '275,298,299,301', 'Carrer de Maladeta', '1', 9, '08016', 41.431593, 2.176909, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1d522724-f923-4f38-aa41-8777fac68c97', '2018-09-03 17:20:27', null, '301 - C/MARIE CURIE, 8-14', 'BIKE', '301',
 '290,294,295,299', 'Marie Curie', '8', 9, '08042', 41.437053, 2.169644, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c21a3a83-8d76-4e00-a6f2-526ef6426fef', '2018-09-03 17:20:27', null, '302 - C/CAVALLERS, 41', 'BIKE', '302',
 '303,304,335,336', 'Cavallers', '41', 7, '08034', 41.39065, 2.111615, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('12014480-7e5f-4773-b9d5-7509be1071d3', '2018-09-03 17:20:27', null, '303 - C/CAVALLERS 67', 'BIKE', '303',
 '302,304,335,336', 'Cavallers', '67', 7, '08034', 41.393341, 2.115076, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0af00520-75f7-422f-86c0-afc9cf6c289b', '2018-09-03 17:20:27', null, '304 - PG. MANUEL GIRONA, 7', 'BIKE', '304',
 '203,204,305,335', 'Manuel Girona', '7', 7, '08034', 41.390208, 2.121029, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('294f422c-1e77-4aea-9e14-1023c7af5f23', '2018-09-03 17:20:27', null, '305 - AV. DIAGONAL, 680', 'BIKE', '305',
 '203,204,305,306', 'Diagonal', '680', 7, '08034', 41.387498, 2.123637, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3db867b3-60b5-4e66-9250-ad23777e5625', '2018-09-03 17:20:27', null, '306 - C/ DOCTOR SALVADOR CARDENAL, 1-5', 'BIKE',
 '306', '199,204,305,310', 'Doctor Salvador Cardenal', '7', 7, '08028', 41.385465, 2.122912, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e7326945-91a9-4159-8152-27f0aadf85f7', '2018-09-03 17:20:27', null, '307 - C/ PINTOR RIBALTA / AV. XILE', 'BIKE',
 '307', '308,309,310,311', 'Pintor Ribalta', null, 7, '08028', 41.379135, 2.113505, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3b9b8bd1-2c3b-46b2-b1f7-9e321dd8576f', '2018-09-03 17:20:27', null, '308 - C/CARDENAL REIG, 11', 'BIKE', '308',
 '307,309,310,311', 'Cardenal Reig', '11', 7, '08028', 41.376788, 2.113864, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('19a2026d-566f-4652-b316-0745b2db9fe5', '2018-09-03 17:20:27', null, '309 - C/SANT RAMON NONAT,  26', 'BIKE', '309',
 '307,308,310,311', 'Sant Ramón Nonat', '26', 7, '08028', 41.37674, 2.116973, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e1aa627e-f983-4517-aab8-75dd368ba891', '2018-09-03 17:20:27', null, '310 - C/ JOSEP SAMITIER / JOAN XXIII', 'BIKE',
 '310', '306,307,309,311', 'Josep Samitier', null, 7, '08028', 41.381223, 2.119077, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e2808e99-ba66-4aa8-959f-06a65857940b', '2018-09-03 17:20:27', null, '311 - C/GALLEGO, 2', 'BIKE', '311',
 '307,308,309,310', 'Gallego-Arístides Maillol', '2', 7, '08028', 41.378638, 2.120393, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('bbf1c43a-3279-44a1-a656-39b01ec1e9cb', '2018-09-03 17:20:27', null, '312 - C/ ARIZALA, 77', 'BIKE', '312',
 '193,199,311,353', 'Arizala', '77', 7, '08028', 41.379046, 2.123253, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8cf84605-3382-4053-8cb1-2d802b9b6d81', '2018-09-03 17:20:27', null, '313 - C/ FELIU DE CASANOVA, 1', 'BIKE', '313',
 '185,188,314,354', 'Feliu de Casanova', '1', 3, '08028', 41.375366, 2.129847, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b404bec7-6b67-4e88-8a66-1a5fcdf9f033', '2018-09-03 17:20:27', null, '314 - RAMBLA DEL BRASIL, 44', 'BIKE', '314',
 '192,193,313,354', 'Rambla del Brasil', '44', 3, '08028', 41.37836, 2.129737, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('54c76c3d-8f2a-431a-b841-290d0940c10e', '2018-09-03 17:20:27', null, '315 - C/ DEL GUINARDÓ, 32-38', 'BIKE', '315',
 '177,239,241,280', 'Guinardó', '32', 8, '08025', 41.415617, 2.181966, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4973656a-6926-4a90-b8f5-cb84b31f913d', '2018-09-03 17:20:27', null, '316 - C/ CANTÀBRIA, 55', 'BIKE', '316',
 '128,130,131,317', 'Cantàbria', '55', 8, '08020', 41.422212, 2.198316, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('020d0c5b-db82-47b9-9bb8-df3de2975336', '2018-09-03 17:20:27', null, '317 - RAMBLA DE PRIM, 256', 'BIKE', '317',
 '130,131,316,391', 'Rambla Prim', '256', 8, '08020', 41.425566, 2.200693, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ddaea7d0-25ba-492a-abca-7538e2e9bc66', '2018-09-03 17:20:27', null, '318 - C/ CARTAGENA, 368', 'BIKE', '318',
 '21,276,278,279', 'Cartagena', '83', 4, '08041', 41.413406, 2.171331, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c48a9502-9312-46f5-9243-c292ab9b79d9', '2018-09-03 17:20:27', null, '319 - C/ SAGUÉS, 1', 'BIKE', '319',
 '101,102,216,219', 'Saguès', '1', 6, '08021', 41.393713, 2.145584, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('7e3224e6-97eb-4be2-a0cb-ec91a13676ce', '2018-09-03 17:20:27', null, '320 - VÍA AUGUSTA, 109', 'BIKE', '320',
 '217,221,230,321', 'Vía Augusta', '21', 6, '08006', 41.401118, 2.147989, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('03cb4c0b-8538-4fb0-b8aa-2727471947f7', '2018-09-03 17:20:27', null, '321 - C/ SANT HERMENEGILD, 30', 'BIKE', '321',
 '217,230,322,326', 'Carrer de Sant Hermenegild', '30', 6, '08006', 41.403054, 2.144549, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('fe5734a0-5fd3-4001-be2f-ced50f9bb872', '2018-09-03 17:20:27', null, '322 - C/SANTALÓ, 165', 'BIKE', '322',
 '217,323,324,328', 'Santaló', '165', 6, '08021', 41.400977, 2.13907, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3c9636b8-cca3-4a15-8839-b8a0e02f5269', '2018-09-03 17:20:27', null, '323 - C/VALLMAJOR, 13', 'BIKE', '323',
 '214,215,217,324', 'Vallmajor', '13', 6, '08021', 41.397996, 2.138717, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('847a5905-8acc-4963-a78b-4db258ee5906', '2018-09-03 17:20:27', null, '324 - C/REINA VICTORIA, 31', 'BIKE', '324',
 '214,215,322,323', 'Reina Victoria', '31', 6, '08021', 41.396938, 2.136258, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b6e3acf1-dd44-42fd-8420-d64a647f6921', '2018-09-03 17:20:27', null, '325 - C/ALT DE GIRONELLA, 13', 'BIKE', '325',
 '212,214,331,333', 'Alt de Gironella', '13', 6, '08017', 41.39493, 2.130325, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2d4001da-5ae9-4642-8c2b-8f38e270f18d', '2018-09-03 17:20:28', null, '326 - C/BALMES, 409', 'BIKE', '326',
 '321,327,328,330', 'Balmes', '409', 6, '08022', 41.407384, 2.1383, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d0692453-dfc7-470a-9ad6-fca48f484906', '2018-09-03 17:20:28', null, '327 - C/ REUS, 23', 'BIKE', '327',
 '321,322,326,328', 'Reus', '23', 6, '08022', 41.405, 2.13453, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('01e12a07-d71f-4835-ba57-dc1bc717289f', '2018-09-03 17:20:28', null, '328 - C/ARTESA DE SEGRE, 2', 'BIKE', '328',
 '321,322,327,329', 'Artesa de Segre', '2', 6, '08022', 41.40293, 2.13427, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6a0b95a6-dbc5-476b-986e-6d2251239a0a', '2018-09-03 17:20:28', null, '329 - C/DE LES ESCOLES PIES, 99', 'BIKE', '329',
 '327,328,330,332', 'Carrer de les Escoles Pies', '99', 6, '08017', 41.402879, 2.128541, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('15aa0203-5c0f-4da9-978a-392d55c59459', '2018-09-03 17:20:28', null, '330 - C/DOCTOR CARULLA, 44', 'BIKE', '330',
 '328,329,331,332', 'Doctor Carulla', '44', 6, '08017', 41.400587, 2.130658, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0d42e5ef-03db-4fd3-8c38-3e8f1c217a7d', '2018-09-03 17:20:28', null, '331 - C/ CASTELLNOU, 65', 'BIKE', '331',
 '325,332,333,335', 'Castellnou', '65', 6, '08017', 41.39706, 2.12801, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('fd564446-334c-4716-aea7-2bb13e0be5e1', '2018-09-03 17:20:28', null, '332 - C/ DOCTOR ROUX, 86', 'BIKE', '332',
 '329,330,331,333', 'Doctor Roux', '86', 6, '08017', 41.399822, 2.12809, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('44a1ec0d-bc71-467b-b480-62a9cf50378f', '2018-09-03 17:20:28', null, '333 - PASSATGE DE SENILLOSA, 3-5', 'BIKE', '333',
 '325,331,335,336', 'Passatge de Senillosa', '3', 6, '08034', 41.395632, 2.125106, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e1b17208-daf5-4564-86dc-329492ea4a3f', '2018-09-03 17:20:28', null, '334 - VIA AUGUSTA 348', 'BIKE', '334',
 '331,332,337,338', 'Via Augusta', '348', 6, '08017', 41.400722, 2.123268, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('9548bc50-3547-4f0c-9497-9b5746692b00', '2018-09-03 17:20:28', null, '335 - C/ SANTA AMÈLIA, 2', 'BIKE', '335',
 '212,304,333,336', 'Santa Amèlia', '2', 6, '08034', 41.393639, 2.123224, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2d4683a7-a407-4888-8425-913293e805e3', '2018-09-03 17:20:28', null, '336 - C/ CAPONATA, 10', 'BIKE', '336',
 '333,335,337,338', 'Caponata', '10', 6, '08034', 41.395274, 2.120973, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3b8abe18-f624-416d-bf57-3971d8f705c5', '2018-09-03 17:20:28', null, '337 - C/ CARME KARR 12-14', 'BIKE', '337',
 '333,334,336,338', 'Carme Karr', '12', 6, '08034', 41.398719, 2.120422, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e9e39dff-fbf0-47ab-83e4-ccc48b9a5d1c', '2018-09-03 17:20:28', null, '338 - AV. J. V. FOIX,  63', 'BIKE', '338',
 '333,334,336,337', 'Avinguda de J.Foix', '63', 6, '08034', 41.397572, 2.119506, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8eaeb24d-c35e-421d-8792-4ddde237149e', '2018-09-03 17:20:28', null, '339 - C/ RAMON TURRÓ, 246', 'BIKE', '339',
 '153,154,165,382', 'Ramon Turró', '246', 8, '08005', 41.401662, 2.205277, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('adbde23c-46f1-4d5c-a5f1-7ac177e9b783', '2018-09-03 17:20:28', null, '340 - C/SANT ADRIÀ, 113', 'BIKE', '340',
 '264,341,343,344', 'Sant Adrià', '113', 10, '08030', 41.436145, 2.204634, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('22251aea-ad7f-4772-91ee-b20e5cc33d07', '2018-09-03 17:20:28', null, '341 - PG. D''ENRIC SANCHIS, 33', 'BIKE', '341',
 '264,340,343,344', 'Passeig Enric Sanchís', '33', 10, '08030', 41.434191, 2.205886, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d6ad6ab5-394b-4f4a-845b-6a04a87d3fe0', '2018-09-03 17:20:28', null, '342 - C/ ROC BORONAT, 134', 'BIKE', '342',
 '142,152,153,393,428', 'Roc Boronat', '134', 8, '08018', 41.403502, 2.193702, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3b5218d7-e9d4-4ab7-bcaf-98ae860649f6', '2018-09-03 17:20:28', null,
 '343 - CAMPANA DE LA MAQUINISTA (SAO PAULO I PL. DE', 'BIKE', '343', '260,264,340,344', 'Campana de la Maquinista',
 null, 10, '08030', 41.438886, 2.199598, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b6b97b0d-abea-483f-a4cb-fd6551a7db35', '2018-09-03 17:20:28', null, '344 - C/ CIUTAT D''ASUNCIÓN, 73 / POTOSÍ',
 'BIKE', '344', '260,263,264,343', 'Ciutat d''Asunción', '73', 10, '08030', 41.443127, 2.199538, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4299b256-8d5e-497e-aa30-abd8e59efc7d', '2018-09-03 17:20:28', null,
 '345 - PL. TERESA DE CLARAMUNT/C/ DELS FERROCARILS', 'BIKE', '345', '179,180,346,351', 'Pl. Teresa de Claramunt', null,
 3, '08038', 41.363093, 2.139771, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('421df503-e7e8-468b-ac03-d83d0dbbe9a9', '2018-09-03 17:20:28', null, '346 - C/ DE LA FONERIA, 33', 'BIKE', '346',
 '345,347,348,349', 'Carrer de la Foneria', '33', 3, '08038', 41.360654, 2.139132, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('09a9bef4-80a3-4ec4-80e0-0bb38ddcd406', '2018-09-03 17:20:28', null, '347 - C/ALTS FORNS, 77', 'BIKE', '347',
 '345,346,348,349', 'Alts Forns', '77', 3, '08038', 41.359496, 2.14182, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('bb16ba3c-3b2c-459f-95bf-9760b350c20e', '2018-09-03 17:20:28', null,
 '348 - JARDINS DE CAN FERRERO/PG.DE LA ZONA FRANCA', 'BIKE', '348', '345,346,347,349', 'Jardins de Can Ferrero', null,
 3, '08038', 41.357067, 2.141563, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('bf948bda-e543-4f8a-9ce6-5dcb4b8b71bf', '2018-09-03 17:20:28', null, '349 - C/ DE L'' ENERGIA, 2 / ALTS FORNS', 'BIKE',
 '349', '345,347,348,351', 'Carrer de l''Energia', '2', 3, '08038', 41.357338, 2.137172, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4532b6f7-fa5f-48b3-8519-7aca186d0737', '2018-09-03 17:20:28', null, '350 - C/VILLAROEL,208', 'BIKE', '350',
 '88,90,101,109', 'Villarroel', '208', 2, '08036', 41.391833, 2.14812, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c150b7a5-03d6-4b1c-96cb-f29e755307d3', '2018-09-03 17:20:28', null, '351 - C/ JANE ADDAMS, 26/ CRTA. DEL PRAT',
 'BIKE', '351', '179,345,352,404', 'Jane Addams', '26', 3, '08038', 41.362135, 2.135637, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('deacef5c-7434-4e2b-8f72-79108273af1c', '2018-09-03 17:20:28', null,
 '352 - C/RADI, 10/GRAN VIA DE LES CORTS CATALANES', 'BIKE', '352', '179,346,351,404', 'Radi', '10', 3, '08098',
 41.36335, 2.134144, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('5d488d69-7f7c-4a73-84d7-3bedfcc19971', '2018-09-03 17:20:28', null, '353 - C/ MUNNÉ  2-6', 'BIKE', '353',
 '309,311,314,354', 'Munné', '6', 3, '08028', 41.375414, 2.123191, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a7427ca3-ad1a-4f05-bc25-3760beaffc3f', '2018-09-03 17:20:28', null, '354 - RAMBLA DEL BRASIL, 5', 'BIKE', '354',
 '188,312,313,314', 'Rambla del Brasil', '5', 3, '08028', 41.37592, 2.13008, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0e6e3e3b-6306-4bea-a361-b327e0b8313e', '2018-09-03 17:20:28', null, '355 - C/ CARRERAS I CANDI, 89', 'BIKE', '355',
 '184,313,353,354', 'Carreras i Candi', '89', 3, '08028', 41.37211, 2.12859, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('881e120b-14c9-480e-af72-ad92b0625fd6', '2018-09-03 17:20:28', null, '356 - C/CAMÈLIES, 73', 'BIKE', '356',
 '227,231,276', 'Camèlies', '73', 3, '08024', 41.413425, 2.163411, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('64d5c393-6e4c-43ba-aa1a-1043acc386ad', '2018-09-03 17:20:28', null, '357 - C/ CARDENER 82', 'BIKE', '357',
 '227,228,231,356', 'Cardener', '82', 5, '08024', 41.410538, 2.1581, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('2edcf1b7-0759-4aec-b415-9b75e81abd7f', '2018-09-03 17:20:28', null, '358 - C/GOMBAU , 24', 'BIKE', '358',
 '34,35,36,390', 'Gombau', '24', 1, '08003', 41.387225, 2.17927, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1e605123-201a-4e9e-9e1f-8d7f17c4d527', '2018-09-03 17:20:28', null, '359 - C/ MÉNDEZ NÚÑEZ, 16', 'BIKE', '359',
 '5,358,362,363', 'Méndez Núñez', '16', 1, '08010', 41.390021, 2.177572, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('95e2f7ad-4856-400c-a665-815883b8f1f9', '2018-09-03 17:20:28', null, '360 - C/ BAILÉN, 62', 'BIKE', '360',
 '15,23,362,413', 'Bailén', '62', 2, '08009', 41.395213, 2.172984, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('cab6f684-1789-4adb-b81a-6c396b9f13a1', '2018-09-03 17:20:28', null, '361 - PG. DE COLOM (LES RAMBLES)', 'BIKE', '361',
 '56,57,376,410', 'Passeig de Colom', null, 1, '08003', 41.376292, 2.178553, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a1e9ee63-7288-44b8-8fcd-f141febee178', '2018-09-03 17:20:28', null, '362 - C/ BAILÉN, 100', 'BIKE', '362',
 '15,22,123,360', 'Bailén', '100', 2, '08009', 41.397006, 2.17057, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0e413165-cac8-430c-915a-cfa8e554e6e2', '2018-09-03 17:20:28', null, '363 -C/ BRUC, 20', 'BIKE', '363',
 '23,34,105,359,412', 'Bruc', '20', 2, '08010', 41.39076, 2.1744, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6c3fab0e-2b9f-4e16-bf23-be89ee721e59', '2018-09-03 17:20:28', null, '364 - PG. DE GRÀCIA, 61', 'BIKE', '364',
 '60,72,92,374', 'Passeig de Gràcia', '61', 2, '08007', 41.39324, 2.16343, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('44a33a26-42fd-413f-a1f0-9da3055e1d8e', '2018-09-03 17:20:28', null, '365 - C/VILADOMAT,244', 'BIKE', '365',
 '75,89,109', 'Viladomat', '244', 2, '08029', 41.387499, 2.14702, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8b919bb4-a016-4a5c-ab6c-057e619dbfd7', '2018-09-03 17:20:29', null, '366 - AV. PAU CASALS, 1', 'BIKE', '366',
 '74,101,102,208', 'Pau Casals', '1', 7, '08021', 41.393037, 2.14358, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('03fa316f-60d0-443a-8462-96aa7f60f64c', '2018-09-03 17:20:29', null, '367 - C/MARQUÈS DE SENTMENAT, 39', 'BIKE', '367',
 '75,196,197,201', 'Sentmenat', '39', 7, '08029', 41.385057, 2.137331, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('afb2e467-1b4b-4a11-8d40-c029f58a9657', '2018-09-03 17:20:29', null, '368 - C/ DIPUTACIÓ, 350', 'BIKE', '368',
 '1,360,362,387', 'Diputació', '350', 2, '08013', 41.396815, 2.175714, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('cbbfdda1-9727-4b2e-8157-3229757dd6de', '2018-09-03 17:20:29', null, '369 - C/CONSELL DE CENT, 482', 'BIKE', '369',
 '1,22,24,30', 'Consell de Cent', '482', 2, '08013', 41.400168, 2.177948, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('f9dda75b-e942-4893-a35a-e5d3b6f7b0c6', '2018-09-03 17:20:29', null, '370 - C/ SARDENYA, 324', 'BIKE', '370',
 '18,19,22,120', 'Sardenya', '234', 2, '08025', 41.403735, 2.172987, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ed63ecb0-f85b-47c3-a392-b1c326570cbf', '2018-09-03 17:20:29', null, '371 - C/ DELS ENAMORATS , 49', 'BIKE', '371',
 '26,30,218,369', 'Carrer dels Enamorats', '49', 2, '08013', 41.404027, 2.181264, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('f3a69049-fc11-4688-93f5-31923cf4c5c9', '2018-09-03 17:20:29', null, '372 - C/ RIBES, 77', 'BIKE', '372',
 '1,16,119,426', 'Ribes', '77', 2, '08013', 41.400167, 2.184362, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0a0f21c8-13ae-45c9-8f3e-11f14a2a5f26', '2018-09-03 17:20:29', null, '373 - AV. PARAL.LEL, 132', 'BIKE', '373',
 '85,86,113,235', 'Av. Paral.lel', '132', 2, '08015', 41.375073, 2.161305, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1a1b772e-9c70-404d-b570-0b100930b63d', '2018-09-03 17:20:29', null, '374 - PG. DE GRÀCIA, 89', 'BIKE', '374',
 '27,68,72,92', 'Passeig de Gràcia', '89', 2, '08008', 41.395, 2.16123, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3180fe74-bc03-499d-a45a-e8dcb725f0e9', '2018-09-03 17:20:29', null, '375 - WORLD TRADE CENTER', 'BIKE', '375',
 '56,57,114,376,410', 'World Trade Center', null, 1, '08039', 41.372154, 2.180701, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('057dbc3f-7052-4f0f-b5ee-42095ce7af49', '2018-09-03 17:20:29', null, '376 - WORLD TRADE CENTER', 'BIKE', '376',
 '56,57,361,375,378', 'World Trade Center', null, 1, '08039', 41.371663, 2.180302, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('53ef0edd-709a-4db6-9094-3b3157f0dc6d', '2018-09-03 17:20:29', null, '377 - PL. ICTÍNEO', 'BIKE', '377',
 '37,38,126,402', 'Pl. Ictíneo', null, 1, '08039', 41.37747, 2.183737, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('bcc1adc0-f720-442d-bff4-13ddcecf387f', '2018-09-03 17:20:29', null, '378 - PL. JOAQUIM XIRAU I PALAU, 1', 'BIKE',
 '378', '56,57,114,425', 'Pl.Joaquim Xira i Palau', '1', 1, '08002', 41.378516, 2.176716, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('9c566c47-1ef5-4dd4-9fb4-d0ee9629cea7', '2018-09-03 17:20:29', null, '379 - PL. SANT MIQUEL, 4', 'BIKE', '379',
 '37,55,378,401', 'Pl. Sant Miquel', '4', 1, '08002', 41.381709, 2.177308, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6c16b2bb-bf18-4ea2-bc86-4a67128099b5', '2018-09-03 17:20:29', null, '380 - C/ DURAN I BAS, 2', 'BIKE', '380',
 '34,36,53,395', 'Duran i Bas', '2', 1, '08002', 41.385463, 2.174252, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('121ae4b1-0d5d-4d41-9b5b-60db46da24c1', '2018-09-03 17:20:29', null, '381 - C/AGUSTÍ DURAN I SANPERE, 10', 'BIKE',
 '381', '51,59,388,415', 'Agustí Duran i Sanpere', '10', 1, '08001', 41.381607, 2.167667, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('88f2ae74-e4fc-4d01-b0da-4dc0b06e2bed', '2018-09-03 17:20:29', null, '382 - C/LOPE DE VEGA, 79', 'BIKE', '382',
 '150,154,155,162', 'Lope de Vega', '79', 8, '08005', 41.403938, 2.204188, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b7e9239f-c81c-4a0a-97b8-cddef6c62d98', '2018-09-03 17:20:29', null, '384 - C/ VILAMARÍ 85', 'BIKE', '384',
 '81,87,100,191', 'Vilamarí', '85', 2, '08015', 41.380708, 2.146793, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6c868247-8b8b-43cd-9a2b-c5497943dccc', '2018-09-03 17:20:29', null, '385 - C/ CASANOVA 119', 'BIKE', '385',
 '76,89,90,110', 'Casanova', '119', 2, '08036', 41.387978, 2.155266, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1c801863-e5f8-4f41-9d6f-469a541865c9', '2018-09-03 17:20:29', null, '386 - AV. PARAL.LEL 164', 'BIKE', '386',
 '85,112,236,237', 'Av.Paral.lel', '164', 2, '08015', 41.375086, 2.156848, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3aa431b7-3007-44b0-a7b5-449b742a0f6f', '2018-09-03 17:20:29', null, '387 - C/ NÀPOLS 125', 'BIKE', '387',
 '1,3,119,414', 'Nàpols', '125', 2, '08013', 41.395796, 2.178784, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('fc0c66b3-2026-4cb5-afa8-d73624cba060', '2018-09-03 17:20:29', null, '388 - C/ RIERA ALTA ,6', 'BIKE', '388',
 '54,58,148,381', 'Riera Alta', '6', 1, '08001', 41.380593, 2.167418, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b8befeb8-384c-46fc-bdf7-63acfeb37c44', '2018-09-03 17:20:29', null, '389 - RECINTE PARC DE LA CIUTADELLA', 'BIKE',
 '389', '6,14,47,118', 'Recinte Parc de la Ciutadella', null, 1, '08018', 41.38739, 2.1875, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('19536908-7b8b-4cfd-994c-01cbed7b0bec', '2018-09-03 17:20:29', null, '390 - C/ COMERÇ, 36', 'BIKE', '390', '7,9,389',
 'Comerç', '36', 1, '08003', 41.386955, 2.18195, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('46d0a331-ad97-4f9c-b6ac-96ba74302724', '2018-09-03 17:20:29', null, '391 - C/ SAGRERA, 74', 'BIKE', '391',
 '238,248,289,423', 'Sagrera', '74', 10, '08020', 41.422873, 2.191204, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('36e95c19-4f25-4d7e-ae31-d52bf0049ed5', '2018-09-03 17:20:29', null, '392 - C/RAMON TURRÓ, 4', 'BIKE', '392',
 '45,47,118,409', 'Ramon Turró', '4', 8, '08005', 41.390595, 2.190681, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c9f8dd83-bba1-4c78-b1c6-8a1f60feed6c', '2018-09-03 17:20:29', null, '393 - C/ LLACUNA, 86', 'BIKE', '393',
 '142,152,153,428', 'Llacuna', '86', 8, '08005', 41.402177, 2.197653, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d861bed5-a3a4-4593-b113-339e5576f3a5', '2018-09-03 17:20:29', null, '394 - C/ DIPUTACIÓ, 226', 'BIKE', '394',
 '79,80,209', 'Diputació', '226', 2, '08011', 41.38733, 2.16305, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('59771dc9-4e89-435d-8d8c-4b4983ef3c5d', '2018-09-03 17:20:29', null, '395 - PL. CATALUNYA, 22', 'BIKE', '395',
 '62,63,64,65', 'Pl. Catalunya', '22', 2, '08002', 41.386009, 2.170212, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8d516b08-8e12-4d64-a1a0-0c6340412e3f', '2018-09-03 17:20:29', null, '396 - C/JOAN MIRÓ, 2-12', 'BIKE', '396',
 '49,117,397,407', 'Joan Miró', '2', 8, '08005', 41.389028, 2.196844, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b16fe582-4b3d-441a-8191-65001a83c09d', '2018-09-03 17:20:29', null, '397 - AV. LITORAL (PG MARÍTIM DEL PORT OLÍMPIC)',
 'BIKE', '397', '69,117,170,172', 'Av. Del Litoral', '24', 8, '08003', 41.388894, 2.199334, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0c61141f-819d-4e27-825c-f314046a1968', '2018-09-03 17:20:29', null,
 '398 - PG. MARÍTIM DE LA BARCELONETA/ANDREA DÒRIA', 'BIKE', '398', '11,12,124,424',
 'Passeig Marítim de la Barceloneta', null, 1, '08003', 41.381011, 2.193502, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b464f99c-840f-41b2-ac78-09bd7f3540e0', '2018-09-03 17:20:29', null, '400 - MOLL ORIENTAL', 'BIKE', '400',
 '31,32,33,41,124', 'Moll Oriental', null, 1, '08003', 41.36958, 2.188017, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('069a9fbc-3db1-42e5-92b9-dbe3d8fc294b', '2018-09-03 17:20:29', null, '401 - PL. ANTONIO LÓPEZ ( VIA LAIETANA)', 'BIKE',
 '401', '37,115,126,402', 'Pl. Antonio López (Via Laietana) annexa a la 37', null, 1, '08003', 41.381241, 2.181838,
 null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('67ef70d1-f28b-448a-b50d-3ce7ccf1495d', '2018-09-03 17:20:29', null, '402 - PG DE COLOM (VIA LAIETANA)', 'BIKE', '402',
 '37,38,377,401', 'Passeig de Colom', null, 1, '08003', 41.380565, 2.182119, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e9853798-8635-4dce-8db0-732067ee0e52', '2018-09-03 17:20:29', null, '404 - C/JUAN GRIS, 28', 'BIKE', '404',
 '179,180,184,352', 'Juan Gris', '28', 3, '08014', 41.365374, 2.133087, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('6d832423-761f-43ea-af74-35e60da9680f', '2018-09-03 17:20:29', null, '405 - C/ COMTE BORRELL, 198', 'BIKE', '405',
 '83,87,110,225', 'Comte Borrell', '198', 2, '08012', 41.38551, 2.152, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('abbcd8fc-d85b-40b8-897c-3cccf4975b14', '2018-09-03 17:20:29', null, '406 - GRAN VIA DE LES CORTS CATALANES, 592',
 'BIKE', '406', '62,78,79,287', 'Gran Via de Les Corts Catalanes', '592', 2, '08007', 41.386512, 2.164597, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a658bacf-2e34-4df6-b3d1-dd0ba49df6c1', '2018-09-03 17:20:30', null, '407 - C/RAMON TRIAS FARGAS, 19', 'BIKE', '407',
 '46,47,69,392', 'Ramon Trias Fargas', '19', 8, '08005', 41.388471, 2.192835, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('9328e6fe-1c12-4f45-a3cf-2a0585dacfbd', '2018-09-03 17:20:30', null, '408 - C/ VILLENA, 11', 'BIKE', '408',
 '46,47,392,409', 'Villena, 11', '11', 8, '08005', 41.388609, 2.19231, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('894e2e72-171e-471f-be65-b02f9012ae36', '2018-09-03 17:20:30', null, '409 -C/ JOAN D''ÀUSTRIA, 31B', 'BIKE', '409',
 '45,47,149,392', 'Joan d''Àustria', '31 B', 8, '08005', 41.392358, 2.192478, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('20e08090-1cdb-4d0c-ab56-27ce43ce0eeb', '2018-09-03 17:20:30', null, '410 - PG DE COLOM (LES RAMBLES)', 'BIKE', '410',
 '56,57,361,375', 'Passeig de Colom, s/n', null, 1, '08003', 41.376433, 2.17871, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('95009e9f-e6c3-4e71-bddb-d110ce29ba7f', '2018-09-03 17:20:30', null, '412 - PL. URQUINAONA, 3', 'BIKE', '412',
 '34,64,65,105,363', 'Pl. Urquinaona', '3', 2, '08010', 41.389012, 2.172667, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('faa2a252-965c-4d77-af73-0c760b9916c3', '2018-09-03 17:20:30', null, '413 - C/BRUC, 66', 'BIKE', '413', '15,23,25,360',
 'Bruc', '66', 2, '08010', 41.393512, 2.170718, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b9d0bbbb-83d7-4eeb-aa6f-c1cb29c2454b', '2018-09-03 17:20:30', null, '414 - C/CASP ,67', 'BIKE', '414',
 '23,360,363,387', 'Casp', '67', 2, '08010', 41.393744, 2.176451, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('20aa2f9f-99f1-4f86-bc5c-e0566c3a4738', '2018-09-03 17:20:30', null, '415 - RAMBLA DEL RAVAL , 13', 'BIKE', '415',
 '54,187,388,416', 'Rambla del Raval', '13', 1, '08001', 41.379374, 2.168921, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e2e5c78d-4c1a-4987-a073-265d9eac58ca', '2018-09-03 17:20:30', null, '416 - RAMBLA DEL RAVAL , 20', 'BIKE', '416',
 '54,187,388,415', 'Rambla del Raval', '20', 1, '08001', 41.378134, 2.16965, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('96e4372e-5579-4e45-a336-8a5ce488aa9a', '2018-09-03 17:20:30', null, '418 - PG DE LLUíS COMPANYS (ARC DE TRIOMF)',
 'BIKE', '418', '6,7,359,419', 'Passeig de Lluís Companys', null, 1, '08003', 41.390943, 2.180251, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('680dbead-ba93-4b65-8a8e-862ed21b24c8', '2018-09-03 17:20:30', null, '419 - PG DE LLUíS COMPANYS (ARC DE TRIOMF)',
 'BIKE', '419', '4,6,8,418', 'Passeig de Lluís Companys', null, 1, '08003', 41.391299, 2.180828, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('81b1e95b-c650-43b6-a0b5-98fe154f816c', '2018-09-03 17:20:30', null, '420 - GRAN VIA DE LES CORTS CATALANES, 361',
 'BIKE', '420', '93,94,95,96', 'Gran Via', '361', 3, '08014', 41.374213, 2.148082, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1417c54d-e1bc-4b18-9bf9-8a6941f146ae', '2018-09-03 17:20:30', null, '421 - PL. DE JOAN PEIRÓ', 'BIKE', '421',
 '98,100,188,210', 'Plaça de Joan Peiró', null, 3, '08014', 41.377845, 2.13923, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('851a0419-76e7-4680-b576-b81cbfa174ad', '2018-09-03 17:20:30', null, '423 - C/ HONDURAS 32-34', 'BIKE', '423',
 '240,248,289,391', 'Carrer d''Hondures', '32', 10, '08027', 41.420201, 2.189532, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('bace02a6-fa1f-4be5-b01a-f38a6f105003', '2018-09-03 17:20:30', null, '424 - PG. MARÍTIM DE LA BARCELONETA', 'BIKE',
 '424', '11,41,124,398', 'Passeig Marítim de la Barceloneta, devant del 5-7', '5', 1, '08013', 41.379632, 2.192662,
 null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('71098474-da8b-4dd7-8e15-505943f5dce0', '2018-09-03 17:20:30', null, '425 - C/ DE CERVELLÓ,5', 'BIKE', '425',
 '50,56,57,114', 'Carrer de Cervelló', '5', 1, '08001', 41.37652, 2.1749, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1a878996-9e8d-4ebc-86ad-5d6f68ab34c5', '2018-09-03 17:20:30', null, '426 - C/ DE RIBES,59 B', 'BIKE', '426',
 '1,24,119,372', 'Carrer de Ribes', '59', 2, '08033', 41.398305, 2.183023, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('13919b63-d93f-4708-99c5-57b330906f21', '2018-09-03 17:20:30', null, '427 - C/ DE SANT PAU, 119/ RONDA SANT PAU',
 'BIKE', '427', '50,148,187,232', 'Carrer de Sant Pau', '119', 1, '08001', 41.375336, 2.168007, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8bf83f02-24c3-4dbe-90a6-d7b35a56a9a8', '2018-09-03 17:20:30', null, '428 - C/ PUJADES, 103', 'BIKE', '428',
 '142,149,153,161', 'Carrer Pujades', '103', 8, '08005', 41.398389, 2.196261, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('0a5c6c84-193d-487b-b6c0-54e39f56712b', '2018-09-03 17:20:30', null, '451 - (PK) C/ JAUME FABRA, 12', 'ELECTRIC_BIKE',
 '451', '453,486', '(PK) C/ JAUME FABRA', '12', 3, '08004', 41.37445, 2.159668, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('5de5a79b-7171-4735-ab11-3a737916477d', '2018-09-03 17:20:30', null, '452 - (PK) C/ PADILLA, 159', 'ELECTRIC_BIKE',
 '452', '459,476', '(PK) C/ PADILLA', '159', 2, '08013', 41.398747, 2.186289, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('23a5ec30-a781-4091-bda4-4d472ed8cbcc', '2018-09-03 17:20:30', null, '453 - (PK) C/ URGELL, 12', 'ELECTRIC_BIKE',
 '453', '451,480', '(PK) C/ URGELL', '14', 2, '08011', 41.379563, 2.16204, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d2619c78-a48f-4982-8fd9-01834cd24556', '2018-09-03 17:20:30', null, '454 - (PK) C/ BILBAO, 24', 'ELECTRIC_BIKE',
 '454', '469', '(PK) C/ BILBAO', '24', 8, '08005', 41.402448, 2.204131, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a1490c13-3c2a-4ed3-9cec-451e79c92051', '2018-09-03 17:20:30', null, '455 - (PK) AV. DEL LITORAL, 34', 'ELECTRIC_BIKE',
 '455', '467,479', '(PK) AV. DEL LITORAL', '34', 1, '08005', 41.388966, 2.19917, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('16c1577b-23db-4622-ab05-67a28f31f9e5', '2018-09-03 17:20:30', null, '456 - (PK) C/ DE FLOS I CALCAT, 2',
 'ELECTRIC_BIKE', '456', '458,470', '(PK) C/ DE FLOS I CALCAT', '2', 7, '08034', 41.389853, 2.128581, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('524e9ee1-284e-46ab-a299-b2f9a7612fad', '2018-09-03 17:20:30', null, '457 - (PK) C/ DE JOSEP BALARÍ, 2',
 'ELECTRIC_BIKE', '457', '465,470', '(PK) C/ DE JOSEP BALARÍ', '2', 6, '08022', 41.401519, 2.134235, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('cd333efe-a61b-4533-936e-ae957a70ccf3', '2018-09-03 17:20:30', null, '458 - (PK) AV. JOAN XXIII, 23-25',
 'ELECTRIC_BIKE', '458', '456,471', '(PK) AV. JOAN XXIII', '23-25', 7, '08028', 41.384344, 2.122085, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('000fc08d-8f3d-41f8-8ed6-32e3a4ca3245', '2018-09-03 17:20:30', null, '459 - (PK) C/ D''ALÍ BEI, 54', 'ELECTRIC_BIKE',
 '459', '452,492', '(PK) C/ D''ALÍ BEI', '54', 1, '08013', 41.393941, 2.181443, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('870c1f58-b631-4da8-95ec-c07ebf2a4ed0', '2018-09-03 17:20:30', null, '460 - (PK) AV. FRANCESC CAMBÓ, 10',
 'ELECTRIC_BIKE', '460', '485,493', '(PK) AV. FRANCESC CAMBÓ', '10', 1, '08003', 41.385702, 2.177316, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('bd3c5366-7afe-4d53-b39c-063a550d7eef', '2018-09-03 17:20:30', null, '461 - (PK) AV. JOSEP TARRADELLAS, 46',
 'ELECTRIC_BIKE', '461', '452,481', '(PK) AV. JOSEP TARRADELLAS', '46', 2, '08029', 41.384111, 2.14274, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1ff55e50-db4b-4fa7-a0d4-298d000f724e', '2018-09-03 17:20:30', null, '462 - (PK) AV. JOSEP TARRADELLAS, 139',
 'ELECTRIC_BIKE', '462', '461,487', '(PK) AV. JOSEP TARRADELLAS', '139', 7, '08029', 41.390125, 2.143221, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('52bbc3cd-5074-46a9-bc1a-815b548e32f6', '2018-09-03 17:20:30', null, '463 - (PK) C/ DE L´ABAT SAFONT, 2',
 'ELECTRIC_BIKE', '463', '453,480', '(PK) C/ DE L´ABAT SAFONT', '2', 1, '08001', 41.375244, 2.169795, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('b71211e2-a829-44a6-9128-93e7e5882508', '2018-09-03 17:20:30', null, '464- (PK) C/ DE RAMON ALBÓ, 77s',
 'ELECTRIC_BIKE', '464', '468,488', '(PK) C/ DE RAMON ALBÓ, 77s', '77', 10, '08027', 41.427727, 2.177205, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('097d26eb-006e-4eb9-935e-97a5ec9d4073', '2018-09-03 17:20:30', null, '465 - (PK) RDA. DEL GENERAL MITRE, 203',
 'ELECTRIC_BIKE', '465', '457,472', '(PK) RDA. DEL GENERAL MITRE', '203', 5, '08023', 41.40542, 2.142456, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('179ce2fc-f48f-466e-a119-dbcdddd70840', '2018-09-03 17:20:30', null, '466 - (PK) PG. MARAGALL, 54', 'ELECTRIC_BIKE',
 '466', '475,488', '(PK) PG. MARAGALL', '54', 8, '08041', 41.415745, 2.180684, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c18c571c-f0d3-4342-b493-b71d5026ff19', '2018-09-03 17:20:30', null, '467 - (PK) C/ DEL DR. AIGUADER, 86-88',
 'ELECTRIC_BIKE', '467', '455,479', '(PK) C/ DEL DR. AIGUADER', '86-88', 1, '08005', 41.38582, 2.194135, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('5e9b70d9-aba1-44f4-8622-c7338df7d61f', '2018-09-03 17:20:30', null, '468 - (PK) C/ DE LES MONGES, 2', 'ELECTRIC_BIKE',
 '468', '464,488', '(PK) C/ DE LES MONGES', '2', 10, '08030', 41.430201, 2.187974, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d3cfadc2-8395-41a7-b83c-7387f9b46c82', '2018-09-03 17:20:30', null, '469 - (PK) RAMBLA DEL POBLENOU, 130',
 'ELECTRIC_BIKE', '469', '454,476', '(PK) RAMBLA DEL POBLENOU', '130', 8, '08005', 41.404362, 2.197132, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a451420c-ae12-4df1-851f-7dc1b6826d72', '2018-09-03 17:20:31', null, '470 - (PK) C/ CARDENAL DE SENTMENAT, 8',
 'ELECTRIC_BIKE', '470', '457,471', '(PK) C/ CARDENAL DE SENTMENAT', '8', 6, '08017', 41.397921, 2.125411, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('69bd1d94-32af-4ef6-b77e-f11a4deed106', '2018-09-03 17:20:31', null, '471 - (PK) C/MARQUÈS DE MULHACÉN, 51',
 'ELECTRIC_BIKE', '471', '458,470', '(PK) C/ MARQUÈS DE MULHACÉN', '51', 6, '08034', 41.39415, 2.114973, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('35b10ff8-ce3d-46eb-ade4-2fb27cc0dcf5', '2018-09-03 17:20:31', null, '472 - (PK) C/ DEL TORRENT DE L´OLLA, 221',
 'ELECTRIC_BIKE', '472', '465,474', '(PK) C/ DEL TORRENT DE L´OLLA', '221', 1, '08012', 41.407353, 2.151341, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('dc17e603-dd01-4c0b-9983-279bcff0fea2', '2018-09-03 17:20:31', null, '473 - (PK) PG. DE GARCIA FÀRIA, 71',
 'ELECTRIC_BIKE', '473', '454,482', '(PK) PG. DE GARCIA FÀRIA', '71', 8, '08019', 41.404459, 2.214978, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('393b80bc-5538-4915-a400-f1de591533a7', '2018-09-03 17:20:31', null, '474 - (PK) PL. GAL·LA PLACÍDIA, 2',
 'ELECTRIC_BIKE', '474', '483,486', '(PK) PL. GAL·LA PLACÍDIA', '2', 5, '08006', 41.3989, 2.153668, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a86b4721-f30f-4d23-83f3-69c9f6cb26fe', '2018-09-03 17:20:31', null, '475 - (PK) C/ DE LA MARINA, 345',
 'ELECTRIC_BIKE', '475', '483,496', '(PK) C/ DE LA MARINA', '345', 4, '08025', 41.408528, 2.169385, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4632a311-f422-4402-93e9-8af6167211e6', '2018-09-03 17:20:31', null, '476 - (PK) C/ DE BADAJOZ, 168', 'ELECTRIC_BIKE',
 '476', '452,469', '(PK) C/ DE BADAJOZ', '168', 8, '08018', 41.402459, 2.19042, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('eebdc36b-0fe9-4725-81f6-5eb8cbacbfb9', '2018-09-03 17:20:31', null, '477- (PK) PG. DE COLOM, 1', 'ELECTRIC_BIKE',
 '477', '478,493', '(PK) PG. DE COLOM', '1', 1, '08003', 41.376648, 2.178745, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('4262ba09-2206-473e-af64-b727aaeb0e74', '2018-09-03 17:20:31', null, '478 - (PK) C/ DEL BALUARD, 27', 'ELECTRIC_BIKE',
 '478', '467,477', '(PK) C/ DEL BALUARD', '27', 1, '08003', 41.3798, 2.1891, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('8095a43d-a95b-4d70-8748-7c8b307aa17b', '2018-09-03 17:20:31', null, '479 - (PK) C/ DE LA MARINA, 13-17',
 'ELECTRIC_BIKE', '479', '455,467', '(PK) C/ DE LA MARINA', '13-17', 1, '08005', 41.387298, 2.196595, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('1806f676-cc4a-44a4-9809-92b9f4bfc634', '2018-09-03 17:20:31', null, '480 - (PK) C/ DELS FLORISTES DE LA RAMBLA',
 'ELECTRIC_BIKE', '480', '463,493', '(PK) C/ DELS FLORISTES DE LA RAMBLA', '8', 1, '08001', 41.381516, 2.170239, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e4d1c379-9b1c-4fc4-b8b2-98f6fd33da04', '2018-09-03 17:20:31', null, '481 - (PK) C/ DE VALÈNCIA, 77', 'ELECTRIC_BIKE',
 '481', '461,495', '(PK) C/ DE VALÈNCIA', '77', 2, '08015', 41.383036, 2.150337, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('137743a8-9de4-48f2-96ff-2742a280e8e1', '2018-09-03 17:20:31', null, '482 - (PK) PL. D''ERNEST LLUCH I MARTIN',
 'ELECTRIC_BIKE', '482', '473,489', '(PK) PL. D''ERNEST LLUCH I MARTIN', 'SN', 8, '08005', 41.41306, 2.22123, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c35225d6-b8ca-4143-b6b7-d76988073d26', '2018-09-03 17:20:31', null, '483 - (PK) C/ DE SIRACUSA, 39-51',
 'ELECTRIC_BIKE', '483', '474,486', '(PK) C/ DE SIRACUSA', '39-51', 2, '08012', 41.401752, 2.160748, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('a7e5209c-db11-4ac5-9806-615311a9e5e2', '2018-09-03 17:20:31', null, '484 - (PK) RAMBLA CATALUNYA - RDA. UNIVERSITAT',
 'ELECTRIC_BIKE', '484', '485,494', '(PK) RAMBLA CATALUNYA - RDA. UNIVERSITAT', 'SN', 2, '08007', 41.388101, 2.166997,
 null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('7e90cb94-1378-4cb7-a95e-f9ace6ec3d03', '2018-09-03 17:20:31', null, '485 - (PK) PLAÇA URQUINAONA', 'ELECTRIC_BIKE',
 '485', '460,492', '(PK) PLAÇA URQUINAONA', 'SN', 1, '08010', 41.389914, 2.173239, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('390417cd-f38a-4a90-a79a-feff80be3282', '2018-09-03 17:20:31', null, '486 - (PK) PG. DE GRÀCIA - DIAGONAL',
 'ELECTRIC_BIKE', '486', '451,474', '(PK) PG. DE GRÀCIA - DIAGONAL', null, 2, '08008', 41.396934, 2.159445, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('9f50a3d5-4115-4491-8688-672e0eda7b86', '2018-09-03 17:20:31', null, '487 - (PK) PL. DE FERRER I CAJIGAL',
 'ELECTRIC_BIKE', '487', '462,481', '(PK) PL. DE FERRER I CAJIGAL', null, 2, '08036', 41.38921, 2.154, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('ac34d4e7-e389-49b0-bdc4-09465c8034a9', '2018-09-03 17:20:31', null, '488 - (PK) C/ DE CIENFUEGOS, 13',
 'ELECTRIC_BIKE', '488', '464,468', '(PK) C/ DE CIENFUEGOS', '13', 10, '08027', 41.423976, 2.184391, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('174ba142-bd83-4413-8072-9ed18e5b95e8', '2018-09-03 17:20:31', null, '489 - (PK) PLAÇA CANONGE RODÓ', 'ELECTRIC_BIKE',
 '489', '469,482', '(PK) PLAÇA CANONGE RODÓ', 'SN', 1, '08026', 41.409532, 2.188282, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('d0530f40-5573-46ba-a3c2-ebd012c78c25', '2018-09-03 17:20:31', null, '491 - (PK) C/ DE CARRERAS I CANDI, 65',
 'ELECTRIC_BIKE', '491', '458,495', '(PK) C/ DE CARRERAS I CANDI', '65', 3, '08014', 41.37252, 2.12898, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('e5983013-77ab-49f1-b6d6-d53fe57dc519', '2018-09-03 17:20:31', null, '492 - PL. TETUAN', 'ELECTRIC_BIKE', '492',
 '459,485', 'PL. DE TETUAN', '8-9', 2, '08010', 41.394232, 2.175278, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('3950d59f-0e64-4653-b6df-3075ed2a6364', '2018-09-03 17:20:31', null, '493 - PL. SANT MIQUEL, 4', 'ELECTRIC_BIKE',
 '493', '460,477', 'PL. SANT MIQUEL', '4', 1, '08002', 41.38186, 2.177086, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('47f3deea-1454-4ed4-87db-7016eb542ae9', '2018-09-03 17:20:31', null, '494 - RAMBLA CATALUNYA/DIPUTACIO',
 'ELECTRIC_BIKE', '494', '484,485', 'RAMBLA CATALUNYA', '31', 2, '08007', 41.389481, 2.165357, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('eac61efd-ae51-4f7c-813d-31ac166628d1', '2018-09-03 17:20:31', null, '495 - C/ DIPUTACIÓ - TARRAGONA', 'ELECTRIC_BIKE',
 '495', '451,481', 'C/ DIPUTACIÓ - TARRAGONA', 'SN', 3, '08014', 41.377191, 2.149283, null);
INSERT INTO station
(station_id, created_at, updated_at, station_detail_name, station_detail_type,
 station_external_data_external_station_id, station_external_data_near_by_external_station_ids, location_address,
 location_address_number, location_district_code, location_zip_code, location_latitude, location_longitude,
 location_geometry)
VALUES
('c307b8bc-07ae-419b-926f-4a74a9beb48e', '2018-09-03 17:20:31', null, '496 - C/ DE PROVENÇA, 445', 'ELECTRIC_BIKE',
 '496', '452,475', 'C/ DE PROVENÇA', '445', 2, '08025', 41.404871, 2.175141, null);
